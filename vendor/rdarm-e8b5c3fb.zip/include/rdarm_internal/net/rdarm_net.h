/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#ifndef RDARM_INCLUDE_RDARM_INTERNAL_NET_RDARM_NET_H_
#define RDARM_INCLUDE_RDARM_INTERNAL_NET_RDARM_NET_H_

#include "rdarm.h"
#include "rdarm_internal/net/cm_event.h"

/**
 * @brief Initialize RDMA_CM for listening new connections.
 *
 * @param rdarm_cb The main structure of RDARM.
 *
 * @return The result of initialization. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int rdarm_net_init(rdarm *rdarm_cb);

/**
 * @brief Stop RDMA_CM.
 *
 * @param rdarm_cb The main structure of RDARM.
 *
 * @return The result of initialization. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int rdarm_net_stop(rdarm *rdarm_cb);

/**
 * @brief Accept a new connection request with creating a Queue Pair, registering Memory Region.
 *
 * @param args general_args. Include rdarm, node, connection.
 *
 */
void *accept_node_connection(void *args);

/**
 * @brief Initialize RDMA_CM and connect to a remote node.
 *
 * @param args general_args. Include rdarm, node, connection.
 *
 * @return The result of initialization. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int connect_node(struct general_args *arg);

/**
 * @brief Destroy a connection
 *
 * @param connection The connection to be destroyed.
 *
 * @return The result of destruction. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int destroy_connection(rdarm_connection *connection);

/**
 * @brief Send a join request to a remote node.
 *
 * @param rdarm_cb The main structure of RDARM.
 * @param node The node to join.
 *
 * @return The result of sending. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int rdarm_send_join_request(rdarm *rdarm_cb, rdarm_node *node);

/**
 * @brief Send a join response to a remote node.
 *
 * @param rdarm_cb The main structure of RDARM.
 * @param node The node to join.
 * @param replay_to The origin request id.
 * @param result The result of join.
 *
 * @return The result of sending. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int rdarm_replay_join_request(rdarm *rdarm_cb, rdarm_node *node, uint32_t replay_to, bool result);

/**
 * @brief Send a sync operation request to a remote node.
 *
 * @param rdarm_cb The main structure of RDARM.
 * @param node The node to do this operation.
 * @param op_request The operation need to be done. The result of get operation will save in it.
 * @param op_replay The result of operation. The error code of operation will save in it if return value is RDARM_ERROR_REMOTE_OPERATION.
 *
 * @return The result of sending. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int rdarm_send_operation_request(rdarm *rdarm_cb,
                                 rdarm_node *node,
                                 rdarm_operation_request *op_request,
                                 rdarm_operation_replay *op_replay);

/**
 * @brief Send a async operation request to a remote node.
 *
 * @param rdarm_cb The main structure of RDARM.
 * @param node The node to do this operation.
 * @param op_request The operation need to be done. The result of get operation will save in it.
 *
 * @return The result of sending. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int rdarm_send_async_operation_request(rdarm *rdarm_cb,
                                 rdarm_node *node,
                                 rdarm_operation_request *op_request);

/**
 * @brief Send a replay of sync operation to a remote node.
 *
 * @param rdarm_cb The main structure of RDARM.
 * @param node The node to do this operation.
 * @param replay_to The origin request id.
 * @param op_replay The result of operation.
 *
 * @return The result of sending. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int rdarm_replay_operation_request(rdarm *rdarm_cb,
                                   rdarm_node *node,
                                   uint32_t replay_to,
                                   rdarm_operation_replay *op_replay);
/**
 * @brief Send a replay of async operation to a remote node.
 *
 * @param rdarm_cb The main structure of RDARM.
 * @param node The node to do this operation.
 * @param op_replay The result of operation.
 *
 * @return The result of sending. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int rdarm_replay_async_operation_request(rdarm *rdarm_cb,
                                         rdarm_node *node,
                                         rdarm_async_operation_replay *op_replay);

/**
 * @brief Send a sync batch operation request to a remote node.
 *
 * @param rdarm_cb The main structure of RDARM.
 * @param node The node to do this operation.
 * @param op_request The request to send.
 * @param op_replay The result of operation.
 *
 * @return The result of sending. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int rdarm_send_batch_operation_request(rdarm *rdarm_cb,
                                       rdarm_node *node,
                                       rdarm_operation_request *op_request,
                                       rdarm_batch_operation_reply *op_reply, uint16_t batch_size);

int rdarm_reply_batch_operation_request(rdarm *rdarm_cb,
                                        rdarm_node *node,
                                        uint32_t replay_to,
                                        rdarm_batch_operation_reply *op_replay, uint16_t batch_size);

#endif //RDARM_INCLUDE_RDARM_INTERNAL_NET_RDARM_NET_H_
