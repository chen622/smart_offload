/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#include <stdio.h>
#include <arpa/inet.h>

#include "rdarm.h"
#include "rdarm_internal/net/rdarm_request.h"

int main() {

  in_addr_t addr1 = inet_addr("10.1.1.1");
  uint64_t hash = XXH3_64bits_withSeed(&addr1, 4, NODE_HASH_SEED) % RDARM_SLOT_NUM;
  printf("10.1.1.1: %ld\n", hash);
  in_addr_t addr2 = inet_addr("10.1.1.2");
  uint64_t hash2 = XXH3_64bits_withSeed(&addr2, 4, NODE_HASH_SEED) % RDARM_SLOT_NUM;
  printf("10.1.1.2: %ld\n", hash2);
  rdarm_five_tuple five_tuple = {
      .ip1 = inet_addr("0.0.0.0"),
  };
  printf("key: %ld\n", XXH3_128bits_withSeed(&five_tuple, 16, SLOT_KEY_SEED).high64  % RDARM_SLOT_NUM);

  struct dict_entry entry;
  printf("key size: %ld\n", sizeof(entry.key));
  printf("dict_entry size: %ld\n", sizeof(entry));
  struct rdarm_complex_communicate_data request;
  printf("rdarm_complex_communicate_data payload size: %ld\n", sizeof(request.payload.operation_request));
  printf("rdarm_complex_communicate_data payload size: %ld\n", sizeof(request.payload.batch_operation_request));
  printf("rdarm_complex_communicate_data size: %ld\n", sizeof(request));
  assert(sizeof(entry.key) == RDARM_KEY_LEN);
  assert(sizeof(dict_entry) == 32);
  assert(sizeof(request.payload) == (RDARM_COMPLEX_COMMUNICATE_DATA_SIZE - RDARM_COMPLEX_COMMUNICATE_DATA_META_SIZE));
  assert(sizeof(rdarm_complex_communicate_data) == RDARM_COMPLEX_COMMUNICATE_DATA_SIZE);

//  rdarm_five_tuple key = {
//      .ip1 = inet_addr("0.0.0.0"),
//      .ip2 = inet_addr("1.1.2.1"),
//      .port1 = 1,
//      .port2 = 2,
//      .proto = IPPROTO_UDP,
//  };
//  for (int i = 0; i < 2; ++i) {
//    printf("hash1: %ld\n", XXH3_128bits_withSeed(&key, sizeof(rdarm_five_tuple), HASHMAP_KEY_SEED).high64);
//    key.ip1++;
//  }
//  for (int i = 0; i < 2; ++i) {
//    key.ip1--;
//    printf("hash2: %ld\n", XXH3_128bits_withSeed(&key, sizeof(rdarm_five_tuple), HASHMAP_KEY_SEED).high64);
//  }
}

