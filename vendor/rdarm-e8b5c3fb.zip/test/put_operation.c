/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#include <rdarm.h>
#include <stdio.h>
#include <sys/time.h>
#include <arpa/inet.h>

extern void time_stat(zlog_category_t *logger, long time_array[], int size, char *prefix_name);
extern int collisions;
extern int remote_access;
const char *pre_value =
    "rdarm12312312313312131231231rdarm12312312313312131231231rdarm12312312313312131231231rdarm12312312313312131231231rdarm12312312313312131231231";

int put_string_operate(rdarm *rdarm_cb, int operations_count, int value_size, char *prefix_name) {
  int ret = 0;
  collisions = 0;
  remote_access = 0;
  const char *pre_key = prefix_name;
  struct timeval start, end;
  char value[value_size];
  memcpy(value, pre_value, value_size);
  long **time_use = 0;
  time_use = calloc(2, sizeof(long *));
  time_use[0] = calloc(operations_count, sizeof(long));
  time_use[1] = calloc(operations_count, sizeof(long));

  for (int i = 0; i < operations_count; ++i) {
    char lkey[RDARM_KEY_LEN] = {0};
    snprintf(lkey, RDARM_KEY_LEN, "%d-%s", i, pre_key);
    gettimeofday(&start, NULL);
    ret = rdarm_set_string_string(rdarm_cb,
                                  lkey,
                                  value,
                                  i % RDARM_HASH_TABLE_NUM);

    if (ret != RDARM_OP_SUCCESS) {
      zlog_error(rdarm_cb->logger, "rdarm set string string failed: %s", rdarm_operation_string(ret));
      goto err;
    } else {
      gettimeofday(&end, NULL);
      time_use[0][i] = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
    }
  }
  zlog_info(rdarm_cb->logger, "finish set %d keys", operations_count);
  time_stat(rdarm_cb->logger, time_use[0], operations_count, prefix_name);
  zlog_info(rdarm_cb->logger, "collisions: %d", collisions);
  zlog_info(rdarm_cb->logger, "remote_access: %d", remote_access);

  for (int i = 0; i < operations_count; ++i) {
    char lkey[RDARM_KEY_LEN] = {0};
    snprintf(lkey, RDARM_KEY_LEN, "%d-%s", i, pre_key);
    char *result_value = 0;
    gettimeofday(&start, NULL);
    ret = rdarm_get_string_string(rdarm_cb, lkey, &result_value, i % RDARM_HASH_TABLE_NUM);
    if (ret != RDARM_OP_SUCCESS) {
      zlog_error(rdarm_cb->logger, "rdarm get string string failed: %s", rdarm_operation_string(ret));
      goto err;
    } else if (strcmp(value, result_value) != 0) {
      zlog_error(rdarm_cb->logger, "rdarm get wrong string value: %s %s", value, result_value);
    } else {
      gettimeofday(&end, NULL);
      time_use[1][i] = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
    }
  }
  zlog_info(rdarm_cb->logger, "finish get %d keys", operations_count);
  time_stat(rdarm_cb->logger, time_use[1], operations_count, prefix_name);

  free(time_use[0]);
  free(time_use[1]);
  free(time_use);
  return 0;

  err:
  free(time_use[0]);
  free(time_use[1]);
  free(time_use);
  return -1;
}

int put_ulong_operate(rdarm *rdarm_cb, int operations_count, char *prefix_name, bool has_put) {
  int ret = 0;
  collisions = 0;
  remote_access = 0;
  rdarm_five_tuple key = {
      .ip1 = inet_addr("0.0.0.0"),
      .ip2 = inet_addr("1.1.2.1"),
      .port1 = 1,
      .port2 = 2,
      .proto = IPPROTO_UDP,
      .prefix = "ul",
  };
  struct timeval start, end;
  long **time_use = 0;
  time_use = calloc(2, sizeof(long *));
  time_use[0] = calloc(operations_count, sizeof(long));
  time_use[1] = calloc(operations_count, sizeof(long));
  if (has_put) {
    for (int i = 0; i < operations_count; ++i) {
      gettimeofday(&start, NULL);
      ret = rdarm_set_tuple_uint64(rdarm_cb,
                                   &key,
                                   i,
                                   i % RDARM_HASH_TABLE_NUM);
      key.ip1++;
      if (ret != RDARM_OP_SUCCESS) {
        zlog_error(rdarm_cb->logger, "rdarm set tuple uint64 failed: %s", rdarm_operation_string(ret));
        i--;
        continue;
      } else {
        gettimeofday(&end, NULL);
        time_use[0][i] = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
      }
    }
    zlog_info(rdarm_cb->logger, "finish set %d keys", operations_count);
    time_stat(rdarm_cb->logger, time_use[0], operations_count, prefix_name);
    zlog_info(rdarm_cb->logger, "collisions: %d", collisions);
    zlog_info(rdarm_cb->logger, "remote_access: %d", remote_access);
  } else {
    key.ip1 += operations_count;
  }
  remote_access = 0;
  for (int i = 0; i < operations_count; ++i) {
    uint64_t result_value = 0;
    gettimeofday(&start, NULL);
    key.ip1--;
    ret = rdarm_get_tuple_uint64(rdarm_cb, &key, &result_value, (operations_count - i - 1) % RDARM_HASH_TABLE_NUM);
    if (ret != RDARM_OP_SUCCESS) {
      zlog_error(rdarm_cb->logger, "rdarm get tuple uint64 failed: %s", rdarm_operation_string(ret));
      return -1;
      i--;
      key.ip1++;
      continue;
    } else if (result_value != (operations_count - i - 1)) {
      zlog_error(rdarm_cb->logger,
                 "rdarm get wrong uint64 value: %d %lu",
                 (operations_count - i - 1),
                 result_value);
      return -2;
    }
    gettimeofday(&end, NULL);
    time_use[1][i] = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
  }
  zlog_info(rdarm_cb->logger, "finish get %d keys", operations_count);
  zlog_info(rdarm_cb->logger, "remote_access: %d", remote_access);
  time_stat(rdarm_cb->logger, time_use[1], operations_count, prefix_name);

  free(time_use[0]);
  free(time_use[1]);
  free(time_use);
  return 0;

}

int put_ulong_operate_batch(rdarm *rdarm_cb,
                            int operations_count,
                            char *prefix_name,
                            uint16_t batch_size,
                            bool has_put) {
  int ret = 0;
  collisions = 0;
  remote_access = 0;
  rdarm_five_tuple key = {
      .ip1 = inet_addr("0.0.0.0"),
      .ip2 = inet_addr("1.1.2.1"),
      .port1 = 1,
      .port2 = 2,
      .proto = IPPROTO_UDP,
      .prefix = "ul",
  };
  struct timeval start, end;
  long **time_use = 0;
  time_use = calloc(2, sizeof(long *));
  time_use[0] = calloc(operations_count, sizeof(long));
  time_use[1] = calloc(operations_count, sizeof(long));
  rdarm_five_tuple keys[batch_size];
  uint64_t values[batch_size];
  uint16_t table_ids[batch_size];
  int results[batch_size];

  if (has_put) {
    for (int i = 0; i < operations_count; ++i) {
      gettimeofday(&start, NULL);
      ret = rdarm_set_tuple_uint64(rdarm_cb,
                                   &key,
                                   i,
                                   i % RDARM_HASH_TABLE_NUM);
      key.ip1++;
      if (ret != RDARM_OP_SUCCESS) {
        zlog_error(rdarm_cb->logger, "rdarm set tuple uint64 failed: %s", rdarm_operation_string(ret));
        i--;
        continue;
      } else {
        gettimeofday(&end, NULL);
        time_use[0][i] = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
      }
    }
    zlog_info(rdarm_cb->logger, "finish set %d keys", operations_count);
    time_stat(rdarm_cb->logger, time_use[0], operations_count, prefix_name);
    zlog_info(rdarm_cb->logger, "collisions: %d", collisions);
    zlog_info(rdarm_cb->logger, "remote_access: %d", remote_access);
  } else {
    key.ip1 += operations_count;
  }
  remote_access = 0;
  for (int i = 0; i < operations_count;) {
    gettimeofday(&start, NULL);
    while (i < operations_count) {
      key.ip1--;
      memcpy(&keys[i % batch_size], &key, sizeof(rdarm_five_tuple));
      table_ids[i % batch_size] = (operations_count - i - 1) % RDARM_HASH_TABLE_NUM;
      results[i % batch_size] = RDARM_OP_BATCH_PROCESSING;
      if (++i % batch_size == 0) {
        break;
      }
    }
    ret = rdarm_get_tuple_uint64_with_batch(rdarm_cb, keys, values, table_ids, batch_size, results);
    if (ret != RDARM_OP_SUCCESS) {
      zlog_error(rdarm_cb->logger, "rdarm get batch tuple uint64 failed: %s", rdarm_operation_string(ret));
      i--;
      key.ip1++;
      continue;
    }
    gettimeofday(&end, NULL);
    for (uint16_t j = 0; j < batch_size; j++) {
      uint16_t ci = (i - j - 1) % batch_size;
      if (results[ci] == RDARM_OP_SUCCESS) {
        if (values[ci] != (operations_count - i + j)) {
          zlog_error(rdarm_cb->logger,
                     "rdarm get wrong uint64 value with batch: %d %lu",
                     (operations_count - i + j),
                     values[ci]);
        }
      } else {
        zlog_error(rdarm_cb->logger,
                   "rdarm one of get batch tuple uint64 failed: %s",
                   rdarm_operation_string(results[ci]));
      }
      time_use[1][i - j - 1] = (1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec) / batch_size;
    }
  }
  zlog_info(rdarm_cb->logger, "finish get %d keys", operations_count);
  zlog_info(rdarm_cb->logger, "remote_access: %d", remote_access);
  time_stat(rdarm_cb->logger, time_use[1], operations_count, prefix_name);

  free(time_use[0]);
  free(time_use[1]);
  free(time_use);
  return 0;

}

int put_ulong_list_operate(rdarm *rdarm_cb, int operations_count, char *prefix_name) {
  int ret = 0;
  collisions = 0;
  remote_access = 0;
  rdarm_five_tuple key = {
      .ip1 = inet_addr("1.0.0.0"),
      .ip2 = inet_addr("1.1.2.1"),
      .port1 = 1,
      .port2 = 2,
      .proto = IPPROTO_UDP,
      .prefix = "ull",
  };
  struct timeval start, end;
  long **time_use = 0;
  time_use = calloc(2, sizeof(long *));
  time_use[0] = calloc(operations_count, sizeof(long));
  time_use[1] = calloc(operations_count, sizeof(long));

  for (int i = 0; i < operations_count; ++i) {
    gettimeofday(&start, NULL);
    ret = rdarm_lpush_tuple_uint64(rdarm_cb,
                                   &key,
                                   i,
                                   i % RDARM_HASH_TABLE_NUM);
    key.ip1++;
    if (ret != RDARM_OP_SUCCESS) {
      zlog_error(rdarm_cb->logger, "(%d) rdarm lpush uint64 list failed: %s", i, rdarm_operation_string(ret));
      goto err;
    } else {
      gettimeofday(&end, NULL);
      time_use[0][i] = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
    }
  }
  zlog_info(rdarm_cb->logger, "finish set %d keys", operations_count);
  time_stat(rdarm_cb->logger, time_use[0], operations_count, prefix_name);
  zlog_info(rdarm_cb->logger, "collisions: %d", collisions);
  zlog_info(rdarm_cb->logger, "remote_access: %d", remote_access);

  for (int i = 0; i < operations_count; ++i) {
    uint64_t result = 0;
    gettimeofday(&start, NULL);
    key.ip1--;
    ret = rdarm_lpop_tuple_uint64(rdarm_cb, &key, &result, (operations_count - i - 1) % RDARM_HASH_TABLE_NUM);
    if (ret != RDARM_OP_SUCCESS) {
      zlog_error(rdarm_cb->logger, "(%d) rdarm lpop uint64 list failed: %s", i, rdarm_operation_string(ret));
      goto err;
    } else if (result != (operations_count - i - 1)) {
      zlog_error(rdarm_cb->logger, "rdarm lpop uint64 list with wrong value: %d %lu", operations_count - i - 1, result);
    } else {
      gettimeofday(&end, NULL);
      time_use[1][i] = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
    }
  }
  zlog_info(rdarm_cb->logger, "finish get %d keys", operations_count);
  time_stat(rdarm_cb->logger, time_use[1], operations_count, prefix_name);

  free(time_use[0]);
  free(time_use[1]);
  free(time_use);
  return 0;

  err:
  free(time_use[0]);
  free(time_use[1]);
  free(time_use);
  return -1;
}

int put_ulong_operate_without_output(rdarm *rdarm_cb,
                                     int operations_count,
                                     bool has_put,
                                     uint16_t cache_rate,
                                     long **time_use) {
  int ret = 0;
  collisions = 0;
  remote_access = 0;
  rdarm_five_tuple cache_key = {
      .ip1 = inet_addr("0.0.0.0"),
      .ip2 = inet_addr("1.1.2.1"),
      .port1 = 1,
      .port2 = 2,
      .proto = IPPROTO_UDP,
      .prefix = "ul",
  };
  rdarm_five_tuple key = {
      .ip1 = inet_addr("0.0.0.0"),
      .ip2 = inet_addr("1.1.2.1"),
      .port1 = 1,
      .port2 = 2,
      .proto = IPPROTO_UDP,
      .prefix = "ul",
  };
  struct timeval start, end;

  if (has_put) {
    for (int i = 0; i < operations_count; ++i) {
      gettimeofday(&start, NULL);
      ret = rdarm_set_tuple_uint64(rdarm_cb,
                                   &key,
                                   i,
                                   i % RDARM_HASH_TABLE_NUM);
      key.ip1++;
      if (ret != RDARM_OP_SUCCESS) {
        zlog_error(rdarm_cb->logger, "rdarm set tuple uint64 failed: %s", rdarm_operation_string(ret));
        i--;
        continue;
      } else {
        gettimeofday(&end, NULL);
        time_use[0][i] = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
      }
    }
    zlog_info(rdarm_cb->logger, "finish set %d keys", operations_count);
    zlog_info(rdarm_cb->logger, "collisions: %d", collisions);
    zlog_info(rdarm_cb->logger, "remote_access: %d", remote_access);
  } else {
    key.ip1 += operations_count;
  }
  remote_access = 0;
  for (int i = 0; i < operations_count; ++i) {
    uint64_t result_value = 0;
    gettimeofday(&start, NULL);
    key.ip1--;
    if (i % 100 > cache_rate) {
      ret = rdarm_get_tuple_uint64(rdarm_cb, &key, &result_value, (operations_count - i - 1) % RDARM_HASH_TABLE_NUM);
      if (ret != RDARM_OP_SUCCESS) {
        zlog_error(rdarm_cb->logger, "rdarm get tuple uint64 failed: %s", rdarm_operation_string(ret));
        i--;
        key.ip1++;
        continue;
      } else if (result_value != (operations_count - i - 1)) {
        zlog_error(rdarm_cb->logger,
                   "rdarm get wrong uint64 value: %d %lu",
                   (operations_count - i - 1),
                   result_value);
      }
    } else {
      ret = rdarm_get_tuple_uint64_with_cache(rdarm_cb,
                                              &cache_key,
                                              &result_value,
                                              0);
      if (ret != RDARM_OP_SUCCESS) {
        zlog_error(rdarm_cb->logger, "rdarm get tuple uint64 failed: %s", rdarm_operation_string(ret));
        continue;
      } else if (result_value != 0) {
        zlog_error(rdarm_cb->logger,
                   "rdarm get wrong cache uint64 value: %d %lu",
                   0,
                   result_value);
      }
    }
    gettimeofday(&end, NULL);
    time_use[1][i] = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
  }
  zlog_info(rdarm_cb->logger, "finish get %d keys", operations_count);
  zlog_info(rdarm_cb->logger, "remote_access: %d", remote_access);

  return 0;
}

int put_ulong_operate_batch_without_output(rdarm *rdarm_cb,
                                     int operations_count,
                                     bool has_put,
                                     uint16_t batch_size) {
  int ret = 0;
  collisions = 0;
  remote_access = 0;
  rdarm_five_tuple key = {
      .ip1 = inet_addr("0.0.0.0"),
      .ip2 = inet_addr("1.1.2.1"),
      .port1 = 1,
      .port2 = 2,
      .proto = IPPROTO_UDP,
      .prefix = "ul",
  };
  rdarm_five_tuple keys[batch_size];
  uint64_t values[batch_size];
  uint16_t table_ids[batch_size];
  int results[batch_size];

  if (has_put) {
    for (int i = 0; i < operations_count; ++i) {
      ret = rdarm_set_tuple_uint64(rdarm_cb,
                                   &key,
                                   i,
                                   i % RDARM_HASH_TABLE_NUM);
      key.ip1++;
      if (ret != RDARM_OP_SUCCESS) {
        zlog_error(rdarm_cb->logger, "rdarm set tuple uint64 failed: %s", rdarm_operation_string(ret));
        i--;
        continue;
      }
    }
    zlog_info(rdarm_cb->logger, "finish set %d keys", operations_count);
    zlog_info(rdarm_cb->logger, "collisions: %d", collisions);
    zlog_info(rdarm_cb->logger, "remote_access: %d", remote_access);
  } else {
    key.ip1 += operations_count;
  }
  remote_access = 0;
  for (int i = 0; i < operations_count;) {
    while (i < operations_count) {
      key.ip1--;
      memcpy(&keys[i % batch_size], &key, sizeof(rdarm_five_tuple));
      table_ids[i % batch_size] = (operations_count - i - 1) % RDARM_HASH_TABLE_NUM;
      results[i % batch_size] = RDARM_OP_BATCH_PROCESSING;
      if (++i % batch_size == 0) {
        break;
      }
    }
    ret = rdarm_get_tuple_uint64_with_batch(rdarm_cb, keys, values, table_ids, batch_size, results);
    if (ret != RDARM_OP_SUCCESS) {
      zlog_error(rdarm_cb->logger, "rdarm get batch tuple uint64 failed: %s", rdarm_operation_string(ret));
      i--;
      key.ip1++;
      continue;
    }
    for (uint16_t j = 0; j < batch_size; j++) {
      uint16_t ci = (i - j - 1) % batch_size;
      if (results[ci] == RDARM_OP_SUCCESS) {
        if (values[ci] != (operations_count - i + j)) {
          zlog_error(rdarm_cb->logger,
                     "rdarm get wrong uint64 value with batch: %d %lu",
                     (operations_count - i + j),
                     values[ci]);
        }
      } else {
        zlog_error(rdarm_cb->logger,
                   "rdarm one of get batch tuple uint64 failed: %s",
                   rdarm_operation_string(results[ci]));
      }
    }
  }
  zlog_info(rdarm_cb->logger, "finish get %d keys", operations_count);
  zlog_info(rdarm_cb->logger, "remote_access: %d", remote_access);
  return 0;
}