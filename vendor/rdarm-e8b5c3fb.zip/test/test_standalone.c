/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#include "rdarm.h"
#include "rdarm_common.h"

#include <stdio.h>

extern int put_string_operate(rdarm *rdarm_cb, int operations_count, int value_size, char *prefix_name);

extern int put_ulong_list_operate(rdarm *rdarm_cb, int operations_count, char *prefix_name);

extern int put_ulong_operate(rdarm *rdarm_cb, int operations_count, char *prefix_name, bool has_put);

int main() {
  const int operations_count = 1000000;

  rdarm *rdarm_cb = 0;
  int ret = 0;

  ret = zlog_init("conf/zlog.conf");
  if (ret) {
    printf("zlog_init failed\n");
    return -1;
  }

  ret = rdarm_init(&rdarm_cb, "0.0.0.0", "0.0.0.0");
  if (ret != RDARM_SUCCESS) {
    printf("rdarm initialize failed: %s\n", rdarm_error_string(ret));
    return -1;
  }

  ret = put_string_operate(rdarm_cb, operations_count, 5, "sstr");
  if (ret != 0) {
    printf("short string failed: %s\n", rdarm_error_string(ret));
    goto err;
  }

  ret = put_ulong_list_operate(rdarm_cb, operations_count, "ulong_list_value");
  if (ret != 0) {
    printf("ulong list failed: %s\n", rdarm_error_string(ret));
    goto err;
  }

  ret = put_ulong_operate(rdarm_cb, operations_count, "ulong_value", true);
  if (ret != 0) {
    printf("ulong failed: %s\n", rdarm_error_string(ret));
    goto err;
  }

  ret = put_string_operate(rdarm_cb, operations_count, 64, "lstr");
  if (ret != 0) {
    printf("long string failed: %s\n", rdarm_error_string(ret));
    goto err;
  }

  ret = rdarm_destroy(rdarm_cb);
  if (ret != RDARM_SUCCESS) {
    printf("rdarm destroy failed: %s\n", rdarm_error_string(ret));
    goto err;
  }

  return 0;

  err:
  ret = rdarm_destroy(rdarm_cb);
  if (ret != RDARM_SUCCESS) {
    printf("rdarm destroy failed: %s\n", rdarm_error_string(ret));
    return -2;
  }
}
