/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#include "rdarm.h"
#include "rdarm_common.h"

#include <stdio.h>
#include <string.h>
#include <xxhash.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <malloc.h>
#include <signal.h>
#include <stdbool.h>
#include <unistd.h>

#ifdef PUT_OPERATION
const bool put_operation = 1;
#else
const bool put_operation = 0;
#endif

extern int put_string_operate(rdarm *rdarm_cb, int operations_count, int value_size, char *prefix_name);

extern int put_ulong_list_operate(rdarm *rdarm_cb, int operations_count, char *prefix_name);

extern int put_ulong_operate(rdarm *rdarm_cb, int operations_count, char *prefix_name, bool has_put);

extern int put_ulong_operate_without_output(rdarm *rdarm_cb,
                                            int operations_count,
                                            bool has_put,
                                            uint16_t cache_rate,
                                            long **time_use);

extern int put_ulong_operate_batch_without_output(rdarm *rdarm_cb,
                                                  int operations_count,
                                                  bool has_put,
                                                  uint16_t batch_size);

extern void print_result(char *file_name, long time_array[], int size, char *head_line, char *suffix_value);

extern int put_ulong_operate_batch(rdarm *rdarm_cb,
                                   int operations_count,
                                   char *prefix_name,
                                   uint16_t batch_size,
                                   bool has_put);

//static bool force_quit = false;
//
//static void signal_handler(int signum) {
//  if (signum == SIGINT || signum == SIGTERM) {
//    force_quit = true;
//  }
//}

int main(int argc, char *argv[]) {
  if (argc != 3) {
    printf("Run with ./test_node_b <self_ip> <peer_ip>\n");
    return -1;
  }
  const int operations_count = 1000000;
  long **time_use = 0;
  time_use = calloc(2, sizeof(long *));
  time_use[0] = calloc(operations_count, sizeof(long));
  time_use[1] = calloc(operations_count, sizeof(long));
  struct timeval start_time, end_time;
  int batch_size = 1;

  rdarm *rdarm_cb = 0;
  int ret = 0;

  ret = zlog_init("conf/zlog.conf");
  if (ret) {
    printf("zlog_init failed\n");
    return -1;
  }

  ret = rdarm_init(&rdarm_cb, argv[1], argv[2]);
  if (ret != RDARM_SUCCESS) {
    zlog_fini();
    printf("rdarm initialize failed: %s\n", rdarm_error_string(ret));
    return -1;
  }

  if (put_operation) {

//    // Cache Test Case
//    ret = put_ulong_operate(rdarm_cb, operations_count, "batch_ulong", true);
//    if (ret != 0) {
//      printf("put ulong failed: %s\n", rdarm_operation_string(ret));
//      goto err;
//    }
//
//    sleep(5);
//
//    ret = put_ulong_operate_without_output(rdarm_cb, operations_count, false, 0, time_use);
//    if (ret != 0) {
//      printf("put ulong failed: %s\n", rdarm_operation_string(ret));
//      goto err;
//    }
//    print_result("cache_benchmark-25-0.csv", time_use[1], operations_count,
//                 "latency,remote_rate,cache_rate", "25%,0%");
//
//    ret = put_ulong_operate_without_output(rdarm_cb, operations_count, false, 25, time_use);
//    if (ret != 0) {
//      printf("put ulong failed: %s\n", rdarm_operation_string(ret));
//      goto err;
//    }
//    print_result("cache_benchmark-25-25.csv", time_use[1], operations_count,
//                 "latency,remote_rate,cache_rate", "25%,25%");
//
//    ret = put_ulong_operate_without_output(rdarm_cb, operations_count, false, 50, time_use);
//    if (ret != 0) {
//      printf("put ulong failed: %s\n", rdarm_operation_string(ret));
//      goto err;
//    }
//    print_result("cache_benchmark-25-50.csv", time_use[1], operations_count,
//                 "latency,remote_rate,cache_rate", "25%,50%");
//
//    sleep(5);
//    ret = put_ulong_operate_without_output(rdarm_cb, operations_count, false, 75, time_use);
//    if (ret != 0) {
//      printf("put ulong failed: %s\n", rdarm_operation_string(ret));
//      goto err;
//    }
//
//    sleep(5);
//    print_result("cache_benchmark-25-75.csv", time_use[1], operations_count,
//                 "latency,remote_rate,cache_rate", "25%,75%");

    // Batch Test Case
    ret = put_ulong_operate(rdarm_cb, operations_count, "batch_ulong", true);
    if (ret != 0) {
      printf("put ulong failed: %s\n", rdarm_operation_string(ret));
      goto err;
    }

    sleep(5);
    ret = put_ulong_operate_batch_without_output(rdarm_cb, operations_count, false, 1);
    if (ret != 0) {
      printf("put ulong failed: %s\n", rdarm_operation_string(ret));
      goto err;
    }

    sleep(5);
    batch_size = 1;
    gettimeofday(&start_time, NULL);
    ret = put_ulong_operate_batch_without_output(rdarm_cb, operations_count, false, batch_size);
    if (ret != 0) {
      printf("put ulong failed: %s\n", rdarm_operation_string(ret));
      goto err;
    }
    gettimeofday(&end_time, NULL);
    time_use[0][batch_size] = (end_time.tv_sec - start_time.tv_sec) * 1000000 + (end_time.tv_usec - start_time.tv_usec);
    zlog_info(rdarm_cb->logger,
              "(Batch %u) Total time: %lu, throughput: %f", batch_size,
              time_use[0][batch_size],
              ((double) operations_count / time_use[0][batch_size] * 1000 * 1000));

    sleep(5);
    batch_size = 8;
    gettimeofday(&start_time, NULL);
    ret = put_ulong_operate_batch_without_output(rdarm_cb, operations_count, false, batch_size);
    if (ret != 0) {
      printf("put ulong failed: %s\n", rdarm_operation_string(ret));
      goto err;
    }
    gettimeofday(&end_time, NULL);
    time_use[0][batch_size] = (end_time.tv_sec - start_time.tv_sec) * 1000000 + (end_time.tv_usec - start_time.tv_usec);
    zlog_info(rdarm_cb->logger, "(Batch %u) Total time: %lu, throughput: %f", batch_size, time_use[0][batch_size],
              ((double) operations_count / time_use[0][batch_size] * 1000 * 1000));

    sleep(5);
    batch_size = 16;
    gettimeofday(&start_time, NULL);
    ret = put_ulong_operate_batch_without_output(rdarm_cb, operations_count, false, batch_size);
    if (ret != 0) {
      printf("put ulong failed: %s\n", rdarm_operation_string(ret));
      goto err;
    }
    gettimeofday(&end_time, NULL);
    time_use[0][batch_size] = (end_time.tv_sec - start_time.tv_sec) * 1000000 + (end_time.tv_usec - start_time.tv_usec);
    zlog_info(rdarm_cb->logger, "(Batch %u) Total time: %lu, throughput: %f", batch_size, time_use[0][batch_size],
              ((double) operations_count / time_use[0][batch_size] * 1000 * 1000));

    sleep(5);
    batch_size = 32;
    gettimeofday(&start_time, NULL);
    ret = put_ulong_operate_batch_without_output(rdarm_cb, operations_count, false, batch_size);
    if (ret != 0) {
      printf("put ulong failed: %s\n", rdarm_operation_string(ret));
      goto err;
    }
    gettimeofday(&end_time, NULL);
    time_use[0][batch_size] = (end_time.tv_sec - start_time.tv_sec) * 1000000 + (end_time.tv_usec - start_time.tv_usec);
    zlog_info(rdarm_cb->logger, "(Batch %u) Total time: %lu, throughput: %f", batch_size, time_use[0][batch_size],
              ((double) operations_count / time_use[0][batch_size] * 1000 * 1000));


//    rdarm_five_tuple five_tuple = {
//        .ip1 = inet_addr("10.1.1.1"),
//    };
//    for (int i = 0; i < 1000; i++) {
//      rdarm_lpush_tuple_uint64(rdarm_cb, &five_tuple, 1000 + i, 0);
//    }

//    sleep(10);
//    for (int i = 0; i < 10; ++i) {
//      zlog_info(rdarm_cb->logger, "------round %d------", i);
//
//      ret = put_ulong_operate_batch(rdarm_cb, operations_count, "batch_ulong", 32, false);
//      if (ret != 0) {
//        printf("put ulong with batch failed: %s\n", rdarm_operation_string(ret));
//        goto err;
//      }
//
//      ret = put_ulong_operate(rdarm_cb, operations_count, "ulong_value", false);
//      if (ret != 0) {
//        printf("put ulong failed: %s\n", rdarm_operation_string(ret));
//        goto err;
//      }
//      sleep(2);
//    }
  }

//  char msg[100] = "";
//  signal(SIGINT, signal_handler);
//  signal(SIGTERM, signal_handler);
//  printf("\nWaiting for new connection...\nType exit to quit\n");
//  while (!force_quit) {
//    scanf("%99s", msg);
//    if (strcmp(msg, "exit") == 0 || strcmp(msg, "quit") == 0) {
//      break;
//    }
//  }

  ret = rdarm_destroy(rdarm_cb);
  if (ret != RDARM_SUCCESS) {
    printf("rdarm destroy failed: %s\n", rdarm_error_string(ret));
    goto err;
  }
  zlog_fini();
  return 0;

  err:
  free(time_use[0]);
  free(time_use[1]);
  free(time_use);

  ret = rdarm_destroy(rdarm_cb);
  zlog_fini();
  if (ret != RDARM_SUCCESS) {
    printf("rdarm destroy failed: %s\n", rdarm_error_string(ret));
    return -2;
  }

}
