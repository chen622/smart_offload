/*
 * MIT License
 *
 * Copyright (c) 2021 zhanliang C (zhanliang@iie.ac.cn)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#ifndef SMART_LOAD_BALANCER_HASH_VALUE_H
#define SMART_LOAD_BALANCER_HASH_VALUE_H

#include <rte_flow.h>
#include <rte_hash.h>
#include <rte_malloc.h>
#include "hash_key.h"
#include "flow_management.h"

/**
 * The value of the flow hash table.
 */
struct conn_table_value
{
    /* 1.The following data is used to implement the connection */
    /* The port of load_balancer to communicate with the peer*/
    uint16_t port;
    /* The flag to determine whether traffic is in or out*/
    uint8_t flag;
    /* The dip*/
    uint32_t dip;

    /* 2.The following data are used for monitoring */
    /* Use the number of cycles of CPU as the time*/
    uint64_t create_at;
    /* Total size of flow */
    uint32_t flow_size;
    /* Total amount of packets in a flow */
    uint32_t packet_amount;

    /* 3.The following data is used to offload*/
    /* Has created rte_flow to offload flow or not */
    uint8_t is_offload;
    /* The rte_flow to handle this flow */
    //struct rte_flow *flow;
};


#endif // SMART_LOAD_BALANCER_HASH_VALUE_H