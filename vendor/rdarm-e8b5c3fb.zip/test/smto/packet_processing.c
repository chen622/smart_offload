/*
 * MIT License
 *
 * Copyright (c) 2021 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include <rte_malloc.h>
#include <sys/time.h>
#include "include/flow_management.h"
#include <arpa/inet.h>

/**> Used to extract useful variables from memory */
static rte_xmm_t mask0 = (rte_xmm_t) {.u32 = {BIT_8_TO_15, ALL_32_BITS,
                                              ALL_32_BITS,
                                              ALL_32_BITS}};

/**
 * Extract ipv4 5 tuple from the mbuf by SSE3 instruction.
 *
 * @param m0 The mbuf memory.
 * @param mask0 The position which doesn't need.
 * @param key The result.
 */
static __rte_always_inline void get_ipv4_5tuple(struct rte_mbuf *m0,
                                                rdarm_five_tuple *key) {
  union ipv4_5tuple_host flow_map_key = {.xmm = {0}};

  __m128i tmpdata0 = _mm_loadu_si128(
      rte_pktmbuf_mtod_offset(m0, __m128i *,
                              sizeof(struct rte_ether_hdr) +
                                  offsetof(struct rte_ipv4_hdr, time_to_live)));

  flow_map_key.xmm = _mm_and_si128(tmpdata0, mask0.x);
//  key->ip1 = rte_be_to_cpu_32(flow_map_key.ip_src);
//  key->ip2 = rte_be_to_cpu_32(flow_map_key.ip_dst);
  key->ip1 = flow_map_key.ip_src;
  key->ip2 = flow_map_key.ip_dst;
  key->port1 = rte_be_to_cpu_16(flow_map_key.port_src);
  key->port2 = rte_be_to_cpu_16(flow_map_key.port_dst);
  key->proto = flow_map_key.proto;
}

/**
 * Check the packet type and process it with corresponding method.
 *
 * @param m The packet raw data.
 * @param args Include rdarm, port_id, queue_id, logger.
 *
 * @return Success or not:
 *     - 0: success.
 *     - 1: unsupported return value of hash map lookup.
 *     - -1: cannot add key into hash map.
 *     - -2: create offload rte_flow failed.
 */
static int packet_processing(struct rte_mbuf *m, struct worker_parameter *args) {
  struct rdarm_five_tuple rdarm_key = {0};
  rdarm_five_tuple global_key = {.ip1 = inet_addr(VIRTUAL_IP),};
  int ret = 0;

  if (m->packet_type & RTE_PTYPE_L3_IPV4 && (m->packet_type & RTE_PTYPE_L4_TCP)) {

    get_ipv4_5tuple(m, &rdarm_key);
//    zlog_debug(args->logger, "get ip header use %f ns", GET_NANOSECOND(start_tsc));

    /* Prepare info for printing*/
    char pkt_info[MAX_ERROR_MESSAGE_LENGTH];
//    dump_pkt_info(&rdarm_key, args->queue_id, pkt_info, MAX_ERROR_MESSAGE_LENGTH);
//    zlog_debug(args->logger, "dump pkt(%s) use %f ns", pkt_info, GET_NANOSECOND(start_tsc));

    uint64_t mapping_port = 0;
    //    ret = rdarm_get_tuple_uint64(args->rdarm_cb, &rdarm_key, &mapping_port, PORT_MAPPING_TABLE);
        ret = rdarm_get_tuple_uint64_with_cache(args->rdarm_cb, &rdarm_key, &mapping_port, PORT_MAPPING_TABLE);
    //    zlog_info(args->logger, "get tuple use %f ns", GET_NANOSECOND(start_tsc));
    if (ret == RDARM_OP_KEY_NOT_EXIST) {
      ret = rdarm_lpop_tuple_uint64(args->rdarm_cb, &global_key, &mapping_port, PORT_POLL_TABLE);
      if (ret != RDARM_OP_SUCCESS) {
        dump_pkt_info(&rdarm_key, args->queue_id, pkt_info, MAX_ERROR_MESSAGE_LENGTH);
        zlog_error(args->logger, "failed to pop a free port(%s): %s", pkt_info, rdarm_operation_string(ret));
        return -2;
      } else { /**> New flow */
        dump_pkt_info(&rdarm_key, args->queue_id, pkt_info, MAX_ERROR_MESSAGE_LENGTH);
        zlog_info(args->logger, "new flow: %s", pkt_info);
        ret = rdarm_set_tuple_uint64(args->rdarm_cb, &rdarm_key, mapping_port, PORT_MAPPING_TABLE);
        if (ret != RDARM_OP_SUCCESS) {
          rdarm_lpush_tuple_uint64(args->rdarm_cb, &global_key, mapping_port, PORT_POLL_TABLE);
          zlog_error(args->logger, "failed to set port mapping record: %s", rdarm_operation_string(ret));
          return -1;
        }
      }
    } else if (ret != RDARM_OP_SUCCESS) {
//      zlog_error(args->logger, "failed to get port mapping record: %s", rdarm_operation_string(ret));
      return -1;
    }  /**> Already has mapping record. */
    rdarm_add_tuple_uint64(args->rdarm_cb, &rdarm_key, 1, PKT_COUNTER_TABLE);
//    rdarm_set_tuple_uint64(args->rdarm_cb, &rdarm_key, 1, PKT_COUNTER_TABLE);
    struct rte_ether_hdr *eth_hdr = rte_pktmbuf_mtod(m, struct rte_ether_hdr *);
    struct rte_ipv4_hdr *ipv4_hdr = (struct rte_ipv4_hdr *) (eth_hdr + 1);
    struct rte_tcp_hdr *tcp_hdr = (struct rte_tcp_hdr *) (ipv4_hdr + 1);
    ipv4_hdr->src_addr = args->rip;
    tcp_hdr->src_port = rte_cpu_to_be_16(mapping_port);
    m->l3_len = sizeof(struct rte_ipv4_hdr);
    m->l4_len = sizeof(struct rte_tcp_hdr);
    m->ol_flags = PKT_TX_IP_CKSUM | PKT_TX_TCP_CKSUM;
  }
  return 0;
}

int process_loop(void *args) {
  unsigned lcore_id;
  lcore_id = rte_lcore_id();
  uint16_t queue_id = ((struct worker_parameter *) args)->queue_id;
  uint16_t port_id = ((struct worker_parameter *) args)->port_id;
  zlog_category_t *logger = ((struct worker_parameter *) args)->logger;
  zlog_info(logger, "worker #%u for queue #%u start working!", lcore_id, queue_id);
  int operations_count = ((struct worker_parameter *) args)->operations_count;
  long *time_use = ((struct worker_parameter *) args)->time_uses;

  /* Pre-allocate the local variable */
  struct rte_mbuf *mbufs[32] = {0};
  uint16_t nb_rx;
  uint16_t nb_tx;
  uint16_t packet_index;
  int count = -500000;
  /* pull packet from queue and process */
  while (!force_quit) {
    nb_rx = rte_eth_rx_burst(port_id, queue_id, mbufs, 32);
    nb_tx = 0;
    if (nb_rx) {
      for (packet_index = 0; packet_index < nb_rx; packet_index++) {
        struct rte_mbuf *m = mbufs[packet_index];
        uint64_t start_tsc = rte_rdtsc();
        if (packet_processing(m, args) == 0) {
          nb_tx++;
          count++;
          if (count >= 0) {
            if (count >= operations_count) {
              return 0;
            }
            time_use[count] = GET_NANOSECOND(start_tsc);
          }
        };
      }
      nb_tx = rte_eth_tx_burst(1 - port_id, queue_id,
                               mbufs, nb_tx);
    }
    /* Free any unsent packets. */
    if (unlikely(nb_tx < nb_rx)) {
      uint16_t buf;
      for (buf = nb_tx; buf < nb_rx; buf++) {
        // zlog_error(logger, "drop %d packets", nb_rx - nb_tx);
        rte_pktmbuf_free(mbufs[buf]);
      }
    }
  }

  return 0;
}
