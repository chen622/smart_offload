/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/
#include "rdarm_internal/rdarm_store.h"

int collisions = 0;

int rdarm_store_init(key_slot **key_slots, rdarm_node *init_owner) {
  *key_slots = calloc(RDARM_SLOT_NUM, sizeof(key_slot));
  for (uint16_t i = 0; i < RDARM_SLOT_NUM; ++i) {
    (*key_slots)[i].slot_id = i;
    (*key_slots)[i].owner = init_owner;
    (*key_slots)[i].state = SLOT_PREPARING;
//    key_slots[i].hash_tables = (dict_hash_table *) calloc(RDARM_HASH_TABLE_NUM, sizeof(dict_hash_table));
    (*key_slots)[i].state = SLOT_STABLE;
  }
  init_owner->slot_amount = RDARM_SLOT_NUM;
  return RDARM_SUCCESS;
}

int rdarm_store_destroy(key_slot *key_slots) {
  for (uint16_t i = 0; i < RDARM_SLOT_NUM; ++i) {
    key_slots[i].state = SLOT_EXITING;
    for (uint16_t j = 0; j < RDARM_HASH_TABLE_NUM; ++j) {
      dict_hash_table *hash_table = &key_slots[i].hash_tables[j];
      for (uint16_t k = 0; k < RDARM_BUCKET_NUM; ++k) {
        if (hash_table->entries[k].type == VALUE_SDS) {
          sdsfree(hash_table->entries[k].value.sds);
        } else if (hash_table->entries[k].type == VALUE_UINT64_LIST) {
          while (hash_table->entries[k].value.uint64_list != NULL) {
            DL_DELETE(hash_table->entries[k].value.uint64_list, hash_table->entries[k].value.uint64_list);
          }
        }
//        while (hash_table->entries[k].next != NULL) {
//          if (hash_table->entries[k].next->type == VALUE_SDS) {
//            sdsfree(hash_table->entries[k].next->value.sds);
//          }
//          dict_entry *next_entry = hash_table->entries[k].next;
//          hash_table->entries[k].next = hash_table->entries[k].next->next;
//          free(next_entry);
//        }
//
//        if (hash_table->entries[k].type == VALUE_SDS) {
//          sdsfree(hash_table->entries[k].value.sds);
//        }
      }
      for (uint16_t k = 0; k < RDARM_ADDITION_BUCKET_NUM; ++k) {
        if (hash_table->addition_entries[k].type == VALUE_SDS) {
          sdsfree(hash_table->addition_entries[k].value.sds);
        } else if (hash_table->addition_entries[k].type == VALUE_UINT64_LIST) {
          while (hash_table->addition_entries[k].value.uint64_list != NULL) {
            DL_DELETE(hash_table->addition_entries[k].value.uint64_list,
                      hash_table->addition_entries[k].value.uint64_list);
          }
        }
      }
    }
  }
  free(key_slots);
  return RDARM_SUCCESS;
}

int rehash_slot(key_slot *key_slots, rdarm_node *self, rdarm_node *others) {
  pthread_rwlock_wrlock(&self->state_lock);
  self->state = RDARM_NODE_STATE_MIGRATING;

  // Clean the slots
  for (uint16_t i = 0; i < RDARM_SLOT_NUM; ++i) {
    key_slots[i].owner = NULL;
  }


  // Set the slot owner of hash target
  key_slots[0].owner = self;
  uint64_t biggest_hash =
      XXH3_64bits_withSeed(&self->address.sin_addr.s_addr, 4, NODE_HASH_SEED) % RDARM_SLOT_NUM;
  biggest_hash = 900;
  key_slots[biggest_hash].owner = self;
  self->slot_amount = 0;
  for (rdarm_node *other = others; other != NULL; other = other->hh.next) {
    uint64_t hash = XXH3_64bits_withSeed(&other->address.sin_addr.s_addr, 4, NODE_HASH_SEED) %
        RDARM_SLOT_NUM;
    hash = 0;
    key_slots[hash].owner = other;
    if (hash > biggest_hash && biggest_hash != 0) {
      key_slots[0].owner = other;
      biggest_hash = hash;
    }
  }

  // Update all slots
  rdarm_node *cur = key_slots[0].owner;
  cur->slot_begin = 0;
  for (uint16_t i = 0; i < RDARM_SLOT_NUM; ++i) {
    if (key_slots[i].owner != NULL && key_slots[i].owner != cur) {
      cur = key_slots[i].owner;
      cur->slot_begin = i;
    }
    key_slots[i].owner = cur;
    cur->slot_amount++;
    if (cur == self) {
      key_slots[i].state = SLOT_MIGRATE_IN;
    }
  }

  pthread_rwlock_unlock(&self->state_lock);
  return RDARM_SUCCESS;
}

int change_slot_owner(key_slot *key_slots, rdarm_node *self, rdarm_node *changer) {
  pthread_rwlock_wrlock(&self->state_lock);
  self->state = RDARM_NODE_STATE_MIGRATING;

  uint16_t target_slot = XXH3_64bits_withSeed(&changer->address.sin_addr.s_addr, 4, NODE_HASH_SEED) % RDARM_SLOT_NUM;
  target_slot = 900;
  uint16_t self_slot = XXH3_64bits_withSeed(&self->address.sin_addr.s_addr, 4, NODE_HASH_SEED) % RDARM_SLOT_NUM;
  self_slot = 0;
  self->slot_begin = self_slot;
  rdarm_node *origin_owner = key_slots[target_slot].owner;
  for (int i = 0; i < RDARM_SLOT_NUM; ++i) {
    int index = (target_slot + i) % RDARM_SLOT_NUM;
    if (key_slots[index].owner != origin_owner || index == self_slot) {
      break;
    }
    if (origin_owner == self) {
      key_slots[index].state = SLOT_MIGRATE_OUT;
    }
    key_slots[index].owner = changer;
    changer->slot_amount++;
    origin_owner->slot_amount--;
  }
  changer->slot_begin = target_slot;

  self->state = RDARM_NODE_STATE_WORKING;
  pthread_rwlock_unlock(&self->state_lock);

  return RDARM_SUCCESS;
}

static inline uint32_t find_empty_addition_slot(dict_entry *addition_entries) {
  for (uint32_t i = 1; i < RDARM_ADDITION_BUCKET_NUM; ++i) {
    if (addition_entries[i].type == VALUE_EMPTY) {
      return i;
    }
  }
  return RDARM_ADDITION_BUCKET_NUM;
}

static inline dict_entry *find_entry(key_slot *key_slot,
                                     uint16_t table_id,
                                     const void *key,
                                     uint16_t key_len) {
  uint16_t entry_index = XXH3_128bits_withSeed(key, key_len, HASHMAP_KEY_SEED).high64
      % RDARM_BUCKET_NUM;
  dict_entry *cur_entry =
      &key_slot->hash_tables[table_id].entries[entry_index];

  while (cur_entry != NULL && cur_entry->type != VALUE_EMPTY) {
    if (memcmp(cur_entry->key.str, key, key_len) == 0) {
      break;
    }
    if (cur_entry->next_index == 0) {
      cur_entry = NULL;
    } else {
      cur_entry = &key_slot->hash_tables[table_id].addition_entries[cur_entry->next_index];
    }
  }
  return cur_entry;
}

static inline dict_entry *find_or_create_entry(key_slot *key_slot,
                                               uint16_t table_id,
                                               const void *key,
                                               uint16_t key_len) {
  dict_entry *cur_entry =
      &key_slot->hash_tables[table_id].entries[XXH3_128bits_withSeed(key, key_len, HASHMAP_KEY_SEED).high64
          % RDARM_BUCKET_NUM];

  dict_entry *pre_entry = NULL;

  while (true) {
    if (cur_entry == NULL) {
      pre_entry->next_index = find_empty_addition_slot(key_slot->hash_tables[table_id].addition_entries);
      cur_entry = &key_slot->hash_tables[table_id].addition_entries[pre_entry->next_index];
      if (pre_entry->next_index == RDARM_ADDITION_BUCKET_NUM) {
        return NULL;
      }
      memcpy(cur_entry->key.str, key, key_len);
      collisions++;
      break;
    }
    if (cur_entry->type == VALUE_EMPTY) {
      memcpy(cur_entry->key.str, key, key_len);
      break;
    }
    if (memcmp(cur_entry->key.str, key, key_len) == 0) {
      break;
    }
    pre_entry = cur_entry;
    if (cur_entry->next_index == 0) {
      cur_entry = NULL;
    } else {
      cur_entry = &key_slot->hash_tables[table_id].addition_entries[cur_entry->next_index];
    }
  }
  return cur_entry;
}

int save_string_value(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, char *value, size_t value_len) {
  if (key_slot->state != SLOT_STABLE) {
    return RDARM_OP_NOT_READY;
  }
  dict_entry *cur_entry = find_or_create_entry(key_slot, table_id, key, key_len);
  if (cur_entry == NULL) {
    return RDARM_OP_TABLE_IS_FULL;
  }

  if (cur_entry->type == VALUE_EMPTY) {
    if (value_len <= 8) { // inline store
      memcpy(cur_entry->value.str, value, value_len);
      cur_entry->type = VALUE_STRING;
    } else { // non-inline store
      cur_entry->value.sds = sdsnewlen(value, value_len);
      cur_entry->type = VALUE_SDS;
    }
    key_slot->hash_tables[table_id].used++;
  } else if (cur_entry->type == VALUE_SDS) {
    cur_entry->value.sds = sdscpylen(cur_entry->value.sds, value, value_len);
  } else if (cur_entry->type == VALUE_STRING) {
    if (value_len <= 8) { // inline store
      memcpy(cur_entry->value.str, value, value_len);
    } else { // non-inline store
      cur_entry->value.sds = sdsnewlen(value, value_len);
      cur_entry->type = VALUE_SDS;
    }
  } else {
    return RDARM_OP_CONFLICT_VALUE_TYPE;

  }

  return RDARM_OP_SUCCESS;
}

int load_string_value(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, char **value) {
  if (key_slot->state != SLOT_STABLE) {
    return RDARM_OP_NOT_READY;
  }
  dict_entry *entry = find_entry(key_slot, table_id, key, key_len);
  if (entry == NULL || entry->type == VALUE_EMPTY) {
    return RDARM_OP_KEY_NOT_EXIST;
  } else if (entry->type == VALUE_STRING) {
    *value = calloc(8, sizeof(char));
    memcpy(*value, entry->value.str, 8);
  } else if (entry->type == VALUE_SDS) {
    *value = calloc(sdslen(entry->value.sds), sizeof(char));
    memcpy(*value, entry->value.sds, sdslen(entry->value.sds));
  } else {
    return RDARM_OP_CONFLICT_VALUE_TYPE;
  }
  return RDARM_OP_SUCCESS;
}

int lpush_uint64_list(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, uint64_t value) {
  if (key_slot->state != SLOT_STABLE) {
    return RDARM_OP_NOT_READY;
  }
  dict_entry *cur_entry = find_or_create_entry(key_slot, table_id, key, key_len);
  if (cur_entry == NULL) {
    return RDARM_OP_TABLE_IS_FULL;
  }

  if (cur_entry->type != VALUE_EMPTY && cur_entry->type != VALUE_UINT64_LIST) {
    return RDARM_OP_CONFLICT_VALUE_TYPE;
  }

  uint64_node *new_node = (uint64_node *) calloc(1, sizeof(uint64_node));
  new_node->value = value;
  DL_PREPEND(cur_entry->value.uint64_list, new_node);
  key_slot->hash_tables[table_id].used++;
  cur_entry->type = VALUE_UINT64_LIST;

  return RDARM_OP_SUCCESS;
}

int lpop_uint64_list(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, uint64_t *value) {
  if (key_slot->state != SLOT_STABLE) {
    return RDARM_OP_NOT_READY;
  }
  dict_entry *entry = find_entry(key_slot, table_id, key, key_len);
  if (entry == NULL || entry->type == VALUE_EMPTY) {
    return RDARM_OP_KEY_NOT_EXIST;
  } else if (entry->value.uint64_list == NULL) {
    return RDARM_OP_EMPTY_LIST;
  } else if (entry->type == VALUE_UINT64_LIST) {
    *value = entry->value.uint64_list->value;
    DL_DELETE(entry->value.uint64_list, entry->value.uint64_list);
    return RDARM_OP_SUCCESS;
  } else {
    return RDARM_OP_CONFLICT_VALUE_TYPE;
  }
}

int save_uint64_value(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, uint64_t value) {
  if (key_slot->state != SLOT_STABLE) {
    return RDARM_OP_NOT_READY;
  }
  dict_entry *cur_entry = find_or_create_entry(key_slot, table_id, key, key_len);
  if (cur_entry == NULL) {
    return RDARM_OP_TABLE_IS_FULL;
  }

  if (cur_entry->type != VALUE_EMPTY && cur_entry->type != VALUE_UINT64) {
    return RDARM_OP_CONFLICT_VALUE_TYPE;
  }
  cur_entry->value.u64 = value;
  cur_entry->type = VALUE_UINT64;
  key_slot->hash_tables[table_id].used++;

  return RDARM_OP_SUCCESS;
}

int add_uint64_value(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, uint64_t value) {
  if (key_slot->state != SLOT_STABLE) {
    return RDARM_OP_NOT_READY;
  }
  dict_entry *cur_entry = find_or_create_entry(key_slot, table_id, key, key_len);
  if (cur_entry == NULL) {
    return RDARM_OP_TABLE_IS_FULL;
  }

  if (cur_entry->type != VALUE_EMPTY && cur_entry->type != VALUE_UINT64) {
    return RDARM_OP_CONFLICT_VALUE_TYPE;
  }
  cur_entry->value.u64 += value;
  cur_entry->type = VALUE_UINT64;

  return RDARM_OP_SUCCESS;
}


int load_uint64_value(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, uint64_t *value) {
  if (key_slot->state != SLOT_STABLE) {
    return RDARM_OP_NOT_READY;
  }
  dict_entry *entry = find_entry(key_slot, table_id, key, key_len);
  if (entry == NULL || entry->type == VALUE_EMPTY) {
    return RDARM_OP_KEY_NOT_EXIST;
  } else if (entry->type == VALUE_UINT64) {
    *value = entry->value.u64;
    return RDARM_OP_SUCCESS;
  } else {
    return RDARM_OP_CONFLICT_VALUE_TYPE;
  }
}

int save_uint64_value_cache(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, uint64_t value) {
  dict_entry *cur_entry = find_or_create_entry(key_slot, table_id, key, key_len);
  if (cur_entry == NULL) {
    return RDARM_OP_TABLE_IS_FULL;
  }

  if (cur_entry->type != VALUE_EMPTY && cur_entry->type != VALUE_UINT64 && cur_entry->type != VALUE_UINT64_CACHE) {
    return RDARM_OP_CONFLICT_VALUE_TYPE;
  }
  cur_entry->value.u64 = value;
  cur_entry->type = VALUE_UINT64_CACHE;

  return RDARM_OP_SUCCESS;
}

int load_uint64_value_cache(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, uint64_t *value){
  dict_entry *entry = find_entry(key_slot, table_id, key, key_len);
  if (entry == NULL || entry->type == VALUE_EMPTY || entry->type == VALUE_UINT64) {
    return RDARM_OP_KEY_NOT_EXIST;
  } else if (entry->type == VALUE_UINT64_CACHE) {
    *value = entry->value.u64;
    return RDARM_OP_SUCCESS;
  } else {
    return RDARM_OP_CONFLICT_VALUE_TYPE;
  }
}
