/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#include "rdarm_common.h"

const char *rdarm_error_string(enum rdarm_error_code code) {
  switch (code) {
    case RDARM_SUCCESS: return "Success";
    case RDARM_ERROR_INVALID_PARAMETER: return "Invalid parameter";
    case RDARM_ERROR_FAILED_TO_ALLOC_MEMORY: return "Failed to alloc memory";
    case RDARM_ERROR_FAILED_TO_CREATE_THREAD: return "Failed to create thread";
    case RDARM_ERROR_FAILED_TO_CREATE_SHARE_STACK: return "Failed to create share stack";
    case RDARM_ERROR_FAILED_TO_CREATE_SPIN_LOCK: return "Failed to create spin lock";
    case RDARM_ERROR_FAILED_TO_SPIN_LOCK: return "Failed to lock/unlock spin lock";
    case RDARM_ERROR_FAILED_TO_CREATE_SEMAPHORE: return "Failed to create semaphore";
    case RDARM_ERROR_FAILED_TO_CHANGE_SEMAPHORE: return "Failed to change semaphore";
    case RDARM_ERROR_INVALID_IP_ADDRESS: return "Invalid address";
    case RDARM_ERROR_NO_IB_DEVICE: return "No InfiniBand device";
    case RDARM_ERROR_CM_EVENT_CHANNEL: return "Failed to create CM event channel";
    case RDARM_ERROR_CM_ID: return "Failed to create CM ID";
    case RDARM_ERROR_PROTECTION_DOMAIN: return "Failed to create Protection Domain";
    case RDARM_ERROR_CM_BIND_ADDRESS: return "Failed to bind CM ID to address";
    case RDARM_ERROR_CM_LISTEN: return "Failed to listen on CM ID";
    case RDARM_ERROR_CM_THREAD: return "Failed to create CM processor thread";
    case RDARM_ERROR_QUEUE_PAIR: return "Failed to create QP for new connection";
    case RDARM_ERROR_COMPLETION_QUEUE: return "Failed to create Completion Queue";
    case RDARM_ERROR_COMPLETION_CHANNEL: return "Failed to create Completion Channel";
    case RDARM_ERROR_NOTIFY_CQ: return "Failed to start CQ notify";
    case RDARM_ERROR_CONFLICT_CONNECTION: return "Conflict connection request";
    case RDARM_ERROR_REGISTER_MR: return "Failed to register MR";
    case RDARM_ERROR_POST_WR: return "Failed to post WR";
    case RDARM_ERROR_ACCEPT_CONNECTION: return "Failed to accept connection";
    case RDARM_ERROR_CQ_EVENT: return "Failed to get CQ event";
    case RDARM_ERROR_RESOLVE_ADDRESS: return "Failed to resolve address";
    case RDARM_ERROR_CREATE_CONNECTION: return "Failed to create connection";
    case RDARM_ERROR_CONNECT: return "Failed to connect";
    case RDARM_ERROR_UNKNOWN_RDMA_OP_CODE : return "Unknown RDMA op code";
    case RDARM_ERROR_UNKNOWN_REQUEST_TYPE: return "Unknown Request Type";
    case RDARM_ERROR_UNKNOWN_OPERATION_TYPE: return "Unknown Operation Type";
    case RDARM_ERROR_NO_FREE_COMMUNICATE_BUFFER: return "No free communicate buffer";
    case RDARM_ERROR_JOIN_ERROR: return "Failed to join cluster";
    case RDARM_ERROR_REMOTE_OPERATION: return "Failed to execute operation in the remote node";
    case RDARM_ERROR_TOO_LONG_BATCH_OPERATION: return "Batch request is too long";
    case RDARM_ERROR_UNKNOWN: return "Unknown error";
    default: return "Undefined error";
  }
}

const char *rdarm_operation_string(enum rdarm_operation_result_type op) {
  switch (op) {
    case RDARM_OP_SUCCESS: return "Success";
    case RDARM_OP_NOT_READY: return "Not ready for operation";
    case RDARM_OP_INVALID_KEY_OR_VALUE: return "Invalid key or value";
    case RDARM_OP_INVALID_KEY_LENGTH: return "Key is too long";
    case RDARM_OP_KEY_NOT_EXIST: return "Key does not exist";
    case RDARM_OP_CONFLICT_VALUE_TYPE: return "Key has different type of value";
    case RDARM_OP_EMPTY_LIST: return "The list is empty";
    case RDARM_OP_TABLE_IS_FULL: return "The table is full";
    case RDARM_OP_UNDEFINED: return "The operation is undefined";
    case RDARM_OP_FAILED_TO_SEND_REMOTE: return "Failed to send operation to remote node";
    case RDARM_OP_NO_CACHE: return "No cache value for this key";
    case RDARM_OP_BATCH_PROCESSING: return "Batch processing";
    default: return "Undefined operation result";
  }
}
