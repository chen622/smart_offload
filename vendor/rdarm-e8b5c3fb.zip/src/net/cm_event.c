/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#include <arpa/inet.h>
#include "rdarm_internal/net/cm_event.h"
#include "rdarm_internal/net/rdarm_net.h"

/**
 * @brief Used to find the node in hash map OTHER.
 *
 * @param rdarm_cb The main structure of rdarm.
 * @param event The event of CM.
 *
 * @return The node in hash map OTHER.
 */
static rdarm_node *find_node(rdarm *rdarm_cb, char *ip) {

  rdarm_node *node = 0;
  HASH_FIND_STR(rdarm_cb->others, ip, node);
  if (node == NULL) {
    node = calloc(1, sizeof(rdarm_node));
    memcpy(node->address_str, ip, INET_ADDRSTRLEN);
    HASH_ADD_STR(rdarm_cb->others, address_str, node);
  }
  return node;
}

/**
 * @brief Used to process the different events of CM.
 *
 * @param rdarm_cb The main structure of rdarm.
 * @param cm_id The CM ID of the event.
 * @param event The event need to be processed.
 *
 * @return The result of processing. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
static int cm_event_handler(struct rdarm *rdarm_cb, struct rdma_cm_id *cm_id,
                            struct rdma_cm_event *event) {
  int ret = 0;

  // If the event is RDMA_CM_EVENT_CONNECT_REQUEST, will return a new cm_id used to accept
  zlog_debug(rdarm_cb->logger, "cm_event type %s cm_id %p",
             rdma_event_str(event->event), cm_id);
  struct general_args *context = (struct general_args *) cm_id->context;

  switch (event->event) {
    case RDMA_CM_EVENT_ADDR_RESOLVED: { // Client try to transfer address to RDMA address.
      ret = rdma_resolve_route(cm_id, RDARM_RESOLVED_ADDRESS_TIMEOUT_MS);
      if (ret) {
        context->connection->connection_state = RDARM_CONNECTION_STATE_ERROR;
        zlog_error(rdarm_cb->logger, "failed to resole route: %s", strerror(errno));
        sem_post(&context->connection->sem);
      }
      break;
    }
    case RDMA_CM_EVENT_ROUTE_RESOLVED: { // Client try to resolve a RDMA route.
      context->connection->connection_state = RDARM_CONNECTION_STATE_CLIENT_ADDRESS_RESOLVED;
      zlog_info(rdarm_cb->logger,
                "%s|Client|%s| RDARM_CONNECTION_STATE_IDLE->RDARM_CONNECTION_STATE_CLIENT_ADDRESS_RESOLVED",
                context->node->address_str, rdarm_connection_type_to_string(context->connection->type));
      sem_post(&context->connection->sem);
      break;
    }
    case RDMA_CM_EVENT_CONNECT_REQUEST: { // Server has a new connect request.
      struct rdarm_connect_param param = {
          .ip = {0},
          .address =0,
          .rkey = 0,
          .type = RDARM_CONNECTION_REQUEST_TYPE_NORMAL,
      };
      memcpy(&param, event->param.conn.private_data, event->param.conn.private_data_len);
      rdarm_node *node = find_node(rdarm_cb, param.ip);
      if (param.type == RDARM_CONNECTION_REQUEST_TYPE_NORMAL) {
        if (node->connection.cm_id != NULL) {
          zlog_error(rdarm_cb->logger, "new connection with a connected node");
          ret = RDARM_ERROR_CONFLICT_CONNECTION;
          break;
        }
        node->connection.remote_address = be64toh(param.address);
        node->connection.remote_key = be32toh(param.rkey);
        node->address.sin_port = RDARM_PORT;
        node->address.sin_family = AF_INET;
        inet_pton(AF_INET, node->address_str, &node->address.sin_addr);
      }

      // Context of this cm_id, which will free before destroy the cm_id.
      struct general_args *arg = (struct general_args *) malloc(sizeof(struct general_args));
      arg->rdarm_cb = rdarm_cb;
      arg->node = node;
      arg->connection = &node->connection;
      cm_id->context = arg;

      if (param.type == RDARM_CONNECTION_REQUEST_TYPE_MIGRATION) {
        node->migrate_connection = calloc(1, sizeof(rdarm_connection));
        node->migrate_connection->type = RDARM_CONNECTION_TYPE_MIGRATION;
        arg->connection = node->migrate_connection;
      }

      arg->connection->cm_id = cm_id;
      arg->connection->connection_state = RDARM_CONNECTION_STATE_SERVER_CONNECT_HANDLE;
      zlog_info(rdarm_cb->logger,
                "%s|Client|%s| RDARM_NODE_STATE_IDLE->RDARM_NODE_STATE_SERVER_CONNECT_HANDLE",
                context->node->address_str, rdarm_connection_type_to_string(context->connection->type));

      pthread_t accept_thread;
      pthread_create(&accept_thread, NULL, accept_node_connection, arg);
      break;
    }
    case RDMA_CM_EVENT_ESTABLISHED: {
      context->connection->connection_state = RDARM_CONNECTION_STATE_CONNECTED;
      sem_post(&context->connection->sem);
      break;
    }
    case RDMA_CM_EVENT_ADDR_ERROR:
    case RDMA_CM_EVENT_ROUTE_ERROR: { // Client side find the server failed.
      context->connection->connection_state = RDARM_CONNECTION_STATE_ERROR;
      sem_post(&context->connection->sem);
      break;
    }
    case RDMA_CM_EVENT_CONNECT_ERROR: { // Client side make connection failed.
      context->connection->connection_state = RDARM_CONNECTION_STATE_ERROR;
      sem_post(&context->connection->sem);
      break;
    }
    case RDMA_CM_EVENT_DISCONNECTED: {
      pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL); // Will cancel this thread by itself.
      if (&context->node->connection
          == context->connection) { // Remove the node if this connection is main connection of node.
        if (context->node->migrate_connection) {
          destroy_connection(context->node->migrate_connection);
          free(context->node->migrate_connection);
        }
        destroy_connection(context->connection);
        context->connection->connection_state = RDARM_CONNECTION_STATE_DISCONNECTED;
        zlog_info(rdarm_cb->logger,
                  "%s|%s| DISCONNECTED",
                  context->node->address_str, rdarm_connection_type_to_string(context->connection->type));
        HASH_DEL(rdarm_cb->others, context->node);
        free(context->node);
      }
      if (context->connection->cm_thread) { // If the node is active side of connection, cancel the cm thread.
//        rdma_destroy_id(context->connection->cm_id);
        pthread_detach(pthread_self());
        free(context);
        pthread_exit(0);
      }
      free(context);
      pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
      break;
    };
    case RDMA_CM_EVENT_REJECTED: {
      context->connection->connection_state = RDARM_CONNECTION_STATE_ERROR;
      sem_post(&context->connection->sem);
      break;
    }
    case RDMA_CM_EVENT_CONNECT_RESPONSE: break;
    case RDMA_CM_EVENT_DEVICE_REMOVAL:break;
    case RDMA_CM_EVENT_MULTICAST_JOIN:break;
    case RDMA_CM_EVENT_MULTICAST_ERROR:break;
    case RDMA_CM_EVENT_ADDR_CHANGE:break;
    case RDMA_CM_EVENT_TIMEWAIT_EXIT:break;
    case RDMA_CM_EVENT_UNREACHABLE:break;
  }
  return ret;
}

void *cm_event_processor(void *arg) {
  pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
  pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL);

  struct rdarm *rdarm_cb = ((struct general_args *) arg)->rdarm_cb;
  struct rdarm_connection *connection = ((struct general_args *) arg)->connection;
  struct rdma_cm_event *event = 0;
  int ret;

  while (1) {
    // TODO: when cm disconnect destroy the client.
    pthread_testcancel();
    ret = rdma_get_cm_event(connection->cm_channel, &event);
    pthread_testcancel();
    if (ret) {
      zlog_error(rdarm_cb->logger, "failed to get CM event: %s", strerror(errno));
      pthread_exit((void *) (intptr_t) 1);
    }
    ret = cm_event_handler(rdarm_cb, event->id, event);
    rdma_ack_cm_event(event);
    if (ret) {
      zlog_error(rdarm_cb->logger, "failed to process CM event: %s", rdarm_error_string(errno));
      pthread_exit((void *) (intptr_t) 2);
    }
  }
}