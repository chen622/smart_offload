/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#include <sys/time.h>
#include "rdarm_internal/net/rdarm_net.h"

void *accept_node_connection(void *args) {
  struct rdarm_connection *connection = ((struct general_args *) args)->connection;
  struct rdarm_node *node = ((struct general_args *) args)->node;
  struct rdarm *rdarm_cb = ((struct general_args *) args)->rdarm_cb;

  int ret = 0;

  ret = setup_qp(rdarm_cb, connection);
  if (ret != RDARM_SUCCESS) {
    free(args);
    return (void *) (long) ret;
  }
  zlog_debug(rdarm_cb->logger, "create QP with %s success", node->address_str);

  if (connection->type == RDARM_CONNECTION_TYPE_MAIN) {
    ret = setup_memory(rdarm_cb, connection);
    if (ret != RDARM_SUCCESS) {
      goto err;
    }
    zlog_debug(rdarm_cb->logger, "register MR for %s success", node->address_str);
  }

  ret = pthread_create(&connection->worker_thread, NULL, message_worker_thread, args);
  if (ret) {
    zlog_error(rdarm_cb->logger, "failed to create server worker thread: %s", strerror(errno));
    ret = RDARM_ERROR_FAILED_TO_CREATE_THREAD;
    goto err2;
  }

  for (uint8_t i = 0; i < RDARM_QP_DEPTH; ++i) {
    ret = post_receive_work_request(rdarm_cb, connection);
    if (ret != RDARM_SUCCESS) {
      goto err3;
    }
  }

  sem_init(&connection->sem, 0, 0);
  pthread_mutex_init(&connection->communicate_buf_mutex, NULL);
  ret = rdma_accept(connection->cm_id, NULL);
  if (ret) {
    zlog_error(rdarm_cb->logger, "failed to accept connection: %s", strerror(errno));
    ret = RDARM_ERROR_ACCEPT_CONNECTION;
    goto err3;
  }

  // Waiting for connection established.
  sem_wait(&connection->sem);
  if (connection->connection_state != RDARM_CONNECTION_STATE_CONNECTED) {
    zlog_error(rdarm_cb->logger, "failed to accept connection: %s", node->address_str);
    ret = RDARM_ERROR_CONNECT;
    goto err3;
  }
  zlog_info(rdarm_cb->logger,
            "%s|Server|%s| RDARM_CONNECTION_STATE_SERVER_CONNECT_HANDLE>RDARM_CONNECTION_STATE_CONNECTED",
            node->address_str, rdarm_connection_type_to_string(connection->type));

  if (connection->type == RDARM_CONNECTION_TYPE_MAIN) {
    // Write the pre-allocate memory info to the client.
    ret = send_pre_allocate_memory_info(rdarm_cb, node);
    if (ret != RDARM_SUCCESS) {
      zlog_error(rdarm_cb->logger, "failed to send pre-alloc memory info: %s", rdarm_error_string(ret));
      goto err4;
    }
  }

  connection->connection_state = RDARM_CONNECTION_STATE_CONNECTED_AND_READY;
  node->state = RDARM_NODE_STATE_CONNECTED;
  zlog_info(rdarm_cb->logger,
            "%s|Server|%s| RDARM_CONNECTION_STATE_CONNECTED>RDARM_CONNECTION_STATE_CONNECTED_AND_READY",
            node->address_str, rdarm_connection_type_to_string(connection->type));

  return (void *) (long) RDARM_SUCCESS;

  err4:
  rdma_disconnect(connection->cm_id);
  err3:
  pthread_cancel(connection->worker_thread);
  pthread_join(connection->worker_thread, NULL);
  pthread_mutex_destroy(&connection->communicate_buf_mutex);
  sem_destroy(&connection->sem);
  err2:
  destroy_memory(connection);
  err:
  destroy_qp(connection);
  connection->connection_state = RDARM_CONNECTION_STATE_ERROR;
  node->state = RDARM_NODE_STATE_ERROR;
  zlog_error(rdarm_cb->logger, "failed to accept node connection");
  free(args);
  return (void *) (long) ret;
}

int destroy_connection(rdarm_connection *connection) {
  if (connection->cm_thread) { // Wait for the cm thread exit, avoiding conflict destroy.
    pthread_cancel(connection->cm_thread);
    pthread_join(connection->cm_thread, NULL);
  }
  if (connection->connection_state
      == RDARM_CONNECTION_STATE_DISCONNECTED) { // If the connection is disconnected by the cm_thread.
    return RDARM_SUCCESS;
  }
  if (connection->cm_thread) {
    rdma_destroy_event_channel(connection->cm_channel);
  }
  if (connection->worker_thread) {
    pthread_cancel(connection->worker_thread);
    pthread_join(connection->worker_thread, NULL);
  }
  pthread_mutex_destroy(&connection->communicate_buf_mutex);
  sem_destroy(&connection->sem);
  destroy_memory(connection);
  destroy_qp(connection);
//  destroy_qp(connection);
//  destroy_memory(connection);
//  rdma_disconnect(connection->cm_id);
//  rdma_destroy_id(connection->cm_id);
  return RDARM_SUCCESS;
}

int rdarm_net_init(rdarm *rdarm_cb) {
  int ret = 0;
  rdarm_node *self_node = &rdarm_cb->self;
  self_node->connection.cm_channel = rdma_create_event_channel();
  if (!self_node->connection.cm_channel) {
    if (errno == ENODEV) {
      ret = RDARM_ERROR_NO_IB_DEVICE;
    } else {
      ret = RDARM_ERROR_CM_EVENT_CHANNEL;
    }
    return ret;
  }
  zlog_debug(rdarm_cb->logger, "create RDMA_CM event channel (Server: %s) success", self_node->address_str);

  struct general_args *args = calloc(1, sizeof(struct general_args));
  args->rdarm_cb = rdarm_cb;
  args->node = self_node;
  args->connection = &self_node->connection;

  ret = rdma_create_id(self_node->connection.cm_channel, &self_node->connection.cm_id, args, RDMA_PS_TCP);
  if (ret) {
    zlog_error(rdarm_cb->logger, "failed to create RDMA_CM ID: %s", strerror(errno));
    ret = RDARM_ERROR_CM_ID;
    goto err;
  }
//  zlog_debug(rdarm_cb->logger, "create RDMA_CM id (Server: %s) success", self_node->address_str);

  ret = rdma_bind_addr(self_node->connection.cm_id, (struct sockaddr *) &self_node->address);
  if (ret) {
    zlog_error(rdarm_cb->logger, "failed to bind address: %s", strerror(errno));
    ret = RDARM_ERROR_CM_BIND_ADDRESS;
    goto err2;
  }

  self_node->pd = ibv_alloc_pd(self_node->connection.cm_id->verbs);
  if (!self_node->pd) {
    zlog_error(rdarm_cb->logger, "failed to allocate PD: %s", strerror(errno));
    ret = RDARM_ERROR_PROTECTION_DOMAIN;
    goto err2;
  }
//  zlog_debug(rdarm_cb->logger, "create Protection Domain success");

  rdarm_cb->key_slots_mr = ibv_reg_mr(self_node->pd,
                                      rdarm_cb->key_slots,
                                      RDARM_SLOT_NUM * sizeof(struct key_slot),
                                      IBV_ACCESS_LOCAL_WRITE | IBV_ACCESS_REMOTE_READ);
  if (!rdarm_cb->key_slots_mr) {
    zlog_error(rdarm_cb->logger, "failed to register MR for key slots: %s", strerror(errno));
    ret = RDARM_ERROR_REGISTER_MR;
    goto err3;
  }

  ret = rdma_listen(self_node->connection.cm_id, 5);
  if (ret) {
    zlog_error(rdarm_cb->logger, "failed to start listening: %s", strerror(errno));
    ret = RDARM_ERROR_CM_LISTEN;
    goto err4;
  }

  // Complete initialization.

  ret = pthread_create(&self_node->connection.cm_thread, NULL, cm_event_processor, args);
  if (ret) {
    zlog_error(rdarm_cb->logger, "failed to create CM processor thread: %s", strerror(errno));
    ret = RDARM_ERROR_CM_THREAD;
    goto err4;
  }

  self_node->state = RDARM_NODE_STATE_LISTENING;
  zlog_info(rdarm_cb->logger, "Self| RDARM_NODE_STATE_IDLE->RDARM_NODE_STATE_LISTENING");

  return RDARM_SUCCESS;

  // Program return with error.
  err4:
  ibv_dereg_mr(rdarm_cb->key_slots_mr);
  err3:
  ibv_dealloc_pd(self_node->pd);
  err2:
  rdma_destroy_id(self_node->connection.cm_id);
  err:
  free(args);
  rdma_destroy_event_channel(self_node->connection.cm_channel);
  self_node->connection.connection_state = RDARM_CONNECTION_STATE_ERROR;
  return ret;
}

int rdarm_net_stop(rdarm *rdarm_cb) {
  int ret = 0;

  rdarm_cb->self.state = RDARM_NODE_STATE_EXIT;

  ret = pthread_cancel(rdarm_cb->self.connection.cm_thread);
  zlog_debug(rdarm_cb->logger, "cm thread cancel with %d", ret);
  void *ret_val;
  pthread_join(rdarm_cb->self.connection.cm_thread, &ret_val);
  zlog_debug(rdarm_cb->logger, "cm thread exit with %ld", (long) ret_val);

  struct rdarm_node *node, *tmp;
  HASH_ITER(hh, rdarm_cb->others, node, tmp) {
    node->state = RDARM_NODE_STATE_EXIT;
    if (node->migrate_connection) {
      rdma_disconnect(node->migrate_connection->cm_id);
      destroy_connection(node->migrate_connection);
      node->migrate_connection->connection_state = RDARM_CONNECTION_STATE_DISCONNECTED;
      free(node->migrate_connection->cm_id->context);
    }
    rdma_disconnect(node->connection.cm_id);
    destroy_connection(&node->connection);
    node->connection.connection_state = RDARM_CONNECTION_STATE_DISCONNECTED;
    free(node->connection.cm_id->context);
    HASH_DEL(rdarm_cb->others, node);
    free(node);
  }

  free(rdarm_cb->self.connection.cm_id->context);
  ibv_dereg_mr(rdarm_cb->key_slots_mr);
  ibv_dealloc_pd(rdarm_cb->self.pd);
  rdma_destroy_id(rdarm_cb->self.connection.cm_id);
  rdma_destroy_event_channel(rdarm_cb->self.connection.cm_channel);

  return RDARM_SUCCESS;
}

int connect_node(struct general_args *args) {
  int ret = 0;
  args->connection->is_active = true;

  ret = make_cm_connection(args);
  if (ret != RDARM_SUCCESS) {
    args->connection->connection_state = RDARM_CONNECTION_STATE_ERROR;
    args->node->state = RDARM_NODE_STATE_ERROR;
    return ret;
  }

  struct rdarm_connect_param conn_param = {.ip={0}, 0, 0, 0};
  if (args->connection->type == RDARM_CONNECTION_TYPE_MAIN) {
    ret = setup_memory(args->rdarm_cb, args->connection);
    if (ret != RDARM_SUCCESS) {
      goto err;
    }
//    zlog_debug(args->rdarm_cb->logger, "register MR for %s success", args->node->address_str);

    conn_param.address = htobe64((uint64_t) args->connection->communicate_buf_array);
    conn_param.rkey = htobe32(args->connection->communicate_mr->rkey);
    conn_param.type = RDARM_CONNECTION_REQUEST_TYPE_NORMAL;
  } else if (args->connection->type == RDARM_CONNECTION_TYPE_MIGRATION) {
    conn_param.type = RDARM_CONNECTION_REQUEST_TYPE_MIGRATION;
  }

  // Create QP, setup memory regions and connect to peer node.
  ret = make_client_side_connection(args, &conn_param);
  if (ret != RDARM_SUCCESS) {
    goto err2;
  }

  if (args->connection->type == RDARM_CONNECTION_TYPE_MAIN) {
    // Check the memory has been written by server or not.
    while (1) {
      union rdarm_simple_communicate_data
          *peer_info = (union rdarm_simple_communicate_data *) args->connection->communicate_buf_array;
      if (peer_info->be_data.size != 0) {
        peer_info->data.buf = be64toh(peer_info->be_data.buf);
        peer_info->data.rkey = be32toh(peer_info->be_data.rkey);
        zlog_debug(args->rdarm_cb->logger, "recv remote address info: %lu %u",
                   peer_info->data.buf, peer_info->data.rkey);
        args->connection->remote_address = peer_info->data.buf;
        args->connection->remote_key = peer_info->data.rkey;
        memset(peer_info, 0, sizeof(union rdarm_simple_communicate_data));
        ((rdarm_complex_communicate_data *)peer_info)->request_type = RDARM_REQUEST_TYPE_FREE;
        break;
      }
    }
  }

  args->connection->connection_state = RDARM_CONNECTION_STATE_CONNECTED_AND_READY;
  zlog_info(args->rdarm_cb->logger,
            "%s|Client|%s| RDARM_CONNECTION_STATE_CONNECTED>RDARM_CONNECTION_STATE_CONNECTED_AND_READY",
            args->node->address_str, rdarm_connection_type_to_string(args->connection->type));

  if (args->connection->type == RDARM_CONNECTION_TYPE_MAIN) {
    args->node->state = RDARM_NODE_STATE_CONNECTED;
  } else if (args->node->migrate_connection == args->connection) {
    args->node->state = RDARM_NODE_STATE_MIGRATING;
  }

  return RDARM_SUCCESS;
  err2:
  destroy_memory(args->connection);
  err:
  destroy_cm_connection(args->connection);
  return ret;
}

int rdarm_send_join_request(rdarm *rdarm_cb, rdarm_node *node) {
  struct timeval start, end;
  gettimeofday(&start, NULL);
  int ret = 0;
  int index = get_free_communicate_buffer(&node->connection);
  if (index == -1) {
    return RDARM_ERROR_NO_FREE_COMMUNICATE_BUFFER;
  }

  rdarm_complex_communicate_data *request = &node->connection.communicate_buf_array[index];
  request->request_type = RDARM_REQUEST_TYPE_JOIN;
  pthread_spin_init(&request->payload.join_request.lock, 0);
  pthread_spin_lock(&request->payload.join_request.lock);
  ret = send_communicate_buffer(rdarm_cb, &node->connection, index, false);
  if (ret != RDARM_SUCCESS) {
    return ret;
  }


  // Wait for the replay.
  pthread_spin_lock(&request->payload.join_request.lock);

  if (node->connection.communicate_buf_array[request->replay_to].payload.join_replay.result) {
    zlog_info(rdarm_cb->logger,
              "%s|Client| JOIN SUCCESS",
              node->address_str);
    node->remote_key_slots_address =
        node->connection.communicate_buf_array[request->replay_to].payload.join_replay.key_slots_addr;
    node->remote_key_slots_key =
        node->connection.communicate_buf_array[request->replay_to].payload.join_replay.key_slots_rkey;
  } else {
    zlog_error(rdarm_cb->logger,
               "%s|Client| JOIN FAILED",
               node->address_str);
    return RDARM_ERROR_JOIN_ERROR;
  }
//  node->connection.communicate_buf_array[request->replay_to].request_type = RDARM_REQUEST_TYPE_FREE;
  pthread_spin_destroy(&request->payload.join_request.lock);
  memset(&node->connection.communicate_buf_array[request->replay_to], 0, sizeof(rdarm_complex_communicate_data));
  memset(request, 0, sizeof(rdarm_complex_communicate_data));
  node->connection.communicate_buf_array[request->replay_to].request_type = RDARM_REQUEST_TYPE_FREE;
  request->request_type = RDARM_REQUEST_TYPE_FREE;
  gettimeofday(&end, NULL);
  zlog_info(rdarm_cb->logger,
            "join request time: %ld us",
            (end.tv_sec - start.tv_sec) * 1000000 + (end.tv_usec - start.tv_usec));

  node->migrate_connection = calloc(1, sizeof(rdarm_connection));
  node->migrate_connection->type = RDARM_CONNECTION_TYPE_MIGRATION;
  struct general_args *args = calloc(1, sizeof(struct general_args));
  args->rdarm_cb = rdarm_cb;
  args->node = node;
  args->connection = node->migrate_connection;
  ret = connect_node(args);
  if (ret != RDARM_SUCCESS) {
    zlog_error(rdarm_cb->logger, "%s|Client| failed to make migration connection", node->address_str);
    return ret;
  }
  ret = rehash_slot(rdarm_cb->key_slots, &rdarm_cb->self, rdarm_cb->others);
  if (ret != RDARM_SUCCESS) {
    zlog_error(rdarm_cb->logger, "%s|Client| failed to rehash slot", node->address_str);
    return ret;
  }

  gettimeofday(&start, NULL);
  ret = read_remote_key_slots(rdarm_cb, &rdarm_cb->self, node);
  if (ret != RDARM_SUCCESS) {
    zlog_error(rdarm_cb->logger, "%s|Client| failed to read remote slot", node->address_str);
    return ret;
  }

  // Waiting for read complete.
  sem_wait(&node->migrate_connection->sem);
  gettimeofday(&end, NULL);
  zlog_info(rdarm_cb->logger,
            "%s| success migrate %d slots %d keys (%lu bytes) in %ld us",
            node->address_str,
            rdarm_cb->self.slot_amount,
            rdarm_cb->self.slot_amount * RDARM_BUCKET_NUM,
            rdarm_cb->self.slot_amount * sizeof(key_slot),
            (end.tv_sec - start.tv_sec) * 1000000 + (end.tv_usec - start.tv_usec));
  for (uint16_t i = rdarm_cb->self.slot_begin; i < rdarm_cb->self.slot_begin + rdarm_cb->self.slot_amount; ++i) {
    rdarm_cb->key_slots[i].owner = &rdarm_cb->self;
    rdarm_cb->key_slots[i].state = SLOT_STABLE;
  }
  pthread_rwlock_wrlock(&rdarm_cb->self.state_lock);
  rdarm_cb->self.state = RDARM_NODE_STATE_WORKING;
  pthread_rwlock_unlock(&rdarm_cb->self.state_lock);

  return RDARM_OP_SUCCESS;
}

int rdarm_replay_join_request(rdarm *rdarm_cb, rdarm_node *node, uint32_t replay_to, bool result) {
  int index = get_free_communicate_buffer(&node->connection);
  if (index == -1) {
    return RDARM_ERROR_NO_FREE_COMMUNICATE_BUFFER;
  }
  rdarm_complex_communicate_data *request = &node->connection.communicate_buf_array[index];
  request->request_type = RDARM_REQUEST_TYPE_JOIN_REPLAY;
  request->replay_to = replay_to;
  request->payload.join_replay.result = result;
  request->payload.join_replay.key_slots_addr = (uint64_t) rdarm_cb->key_slots;
  request->payload.join_replay.key_slots_rkey = rdarm_cb->key_slots_mr->rkey;
  request->payload_size = sizeof(request->payload.join_replay);
  return send_communicate_buffer(rdarm_cb, &node->connection, index, true);
}

int rdarm_send_operation_request(rdarm *rdarm_cb,
                                 rdarm_node *node,
                                 rdarm_operation_request *op_request,
                                 rdarm_operation_replay *op_replay) {
  int index = get_free_communicate_buffer(&node->connection);
  if (index == -1) {
    return RDARM_ERROR_NO_FREE_COMMUNICATE_BUFFER;
  }
  int ret = 0;
  rdarm_complex_communicate_data *request = &node->connection.communicate_buf_array[index];
  request->request_type = RDARM_REQUEST_TYPE_OPERATE;
  request->payload.operation_request = *op_request;
  request->payload_size = sizeof(request->payload.operation_request) - 4;
  pthread_spin_init(&request->payload.operation_request.lock, 1);
  pthread_spin_lock(&request->payload.operation_request.lock);
  ret = send_communicate_buffer(rdarm_cb, &node->connection, index, false);
  if (ret != RDARM_SUCCESS) {
    goto result;
  }

  pthread_spin_lock(&request->payload.operation_request.lock);
  rdarm_complex_communicate_data *response = &node->connection.communicate_buf_array[request->replay_to];
  op_replay->result = response->payload.operation_replay.result;
  if (response->payload.operation_replay.result == RDARM_OP_SUCCESS) {
    zlog_debug(rdarm_cb->logger,
               "%s| OPERATE SUCCESS: %lu",
               node->address_str,
               response->payload.operation_replay.value);
    op_replay->value = response->payload.operation_replay.value;
    ret = RDARM_SUCCESS;
  } else {
    zlog_debug(rdarm_cb->logger,
               "%s| OPERATE FAILED: %s",
               node->address_str,
               rdarm_operation_string(response->payload.operation_replay.result));
    ret = RDARM_ERROR_REMOTE_OPERATION;
  }

  result:
  pthread_spin_destroy(&request->payload.operation_request.lock);
  memset(request, 0, sizeof(rdarm_complex_communicate_data));
  request->replay_to = RDARM_REQUEST_TYPE_OPERATE;
  request->request_type = RDARM_REQUEST_TYPE_FREE;
  return ret;
}

int rdarm_replay_operation_request(rdarm *rdarm_cb,
                                   rdarm_node *node,
                                   uint32_t replay_to,
                                   rdarm_operation_replay *op_replay) {
  int index = get_free_communicate_buffer(&node->connection);
  if (index == -1) {
    return RDARM_ERROR_NO_FREE_COMMUNICATE_BUFFER;
  }
  int ret = 0;
  rdarm_complex_communicate_data *request = &node->connection.communicate_buf_array[index];
  request->request_type = RDARM_REQUEST_TYPE_OPERATE_REPLAY;
  request->replay_to = replay_to;
  request->payload.operation_replay = *op_replay;
  request->payload_size = sizeof(request->payload.operation_replay);

  ret = send_communicate_buffer(rdarm_cb, &node->connection, index, true);
  if (ret != RDARM_SUCCESS) {
    memset(request, 0, sizeof(rdarm_complex_communicate_data));
    request->request_type = RDARM_REQUEST_TYPE_FREE;
  }
  return ret;
}

int rdarm_send_async_operation_request(rdarm *rdarm_cb,
                                       rdarm_node *node,
                                       rdarm_operation_request *op_request) {
  int index = get_free_communicate_buffer(&node->connection);
  if (index == -1) {
    return RDARM_ERROR_NO_FREE_COMMUNICATE_BUFFER;
  }
  rdarm_complex_communicate_data *request = &node->connection.communicate_buf_array[index];
  request->request_type = RDARM_REQUEST_TYPE_ASYNC_OPERATE;
  request->payload.operation_request = *op_request;
  request->payload_size = sizeof(request->payload.operation_request) - 4;
  pthread_spin_init(&request->payload.operation_request.lock, 1);
  pthread_spin_lock(&request->payload.operation_request.lock);
  int ret = send_communicate_buffer(rdarm_cb, &node->connection, index, false);
  if (ret != RDARM_SUCCESS) {
    goto result;
  }

  pthread_spin_lock(&request->payload.operation_request.lock);
  result:
  pthread_spin_destroy(&request->payload.operation_request.lock);
  memset(request, 0, sizeof(rdarm_complex_communicate_data));
  request->replay_to = RDARM_REQUEST_TYPE_ASYNC_OPERATE;
  request->request_type = RDARM_REQUEST_TYPE_FREE;
  return ret;
}

int rdarm_replay_async_operation_request(rdarm *rdarm_cb,
                                         rdarm_node *node,
                                         rdarm_async_operation_replay *op_replay) {
  int index = get_free_communicate_buffer(&node->connection);
  if (index == -1) {
    return RDARM_ERROR_NO_FREE_COMMUNICATE_BUFFER;
  }
  rdarm_complex_communicate_data *request = &node->connection.communicate_buf_array[index];
  request->request_type = RDARM_REQUEST_TYPE_ASYNC_REPLAY;
  request->payload.async_operation_replay = *op_replay;
  request->payload_size = sizeof(request->payload.async_operation_replay);

  int ret = send_communicate_buffer(rdarm_cb, &node->connection, index, true);
  if (ret != RDARM_SUCCESS) {
    memset(request, 0, sizeof(rdarm_complex_communicate_data));
    request->request_type = RDARM_REQUEST_TYPE_FREE;
  }
  return ret;
}

int rdarm_send_batch_operation_request(rdarm *rdarm_cb,
                                       rdarm_node *node,
                                       rdarm_operation_request *op_request,
                                       rdarm_batch_operation_reply *op_reply, uint16_t batch_size) {
  int index = get_free_communicate_buffer(&node->connection);
  if (index == -1) {
    return RDARM_ERROR_NO_FREE_COMMUNICATE_BUFFER;
  }

  int ret = 0;
  uint16_t real_count = 0;

  rdarm_complex_communicate_data *request = &node->connection.communicate_buf_array[index];
  request->request_type = RDARM_REQUEST_TYPE_BATCH_OPERATE;
  request->payload_size =  8;
  for (int i = 0; i < batch_size; ++i) {
    if (op_request[i].type != RDARM_OP_REQUEST_TYPE_UNKNOWN) {
      request->payload.batch_operation_request.type = op_request[i].type;
      request->payload.batch_operation_request.operation_request[real_count].table_id = op_request[i].table_id;
      request->payload.batch_operation_request.operation_request[real_count].original_index = i;
      memcpy(request->payload.batch_operation_request.operation_request[real_count].key,
             op_request[i].key,
             RDARM_KEY_LEN);
      request->payload_size += sizeof(rdarm_batch_operation_request);
      real_count++;
    }
  }
  request->payload.batch_operation_request.amount = real_count;
  pthread_spin_init(&request->payload.batch_operation_request.lock, 1);
  pthread_spin_lock(&request->payload.batch_operation_request.lock);

  if (request->payload_size > RDARM_COMPLEX_COMMUNICATE_DATA_SIZE - RDARM_COMPLEX_COMMUNICATE_DATA_META_SIZE) {
    ret = RDARM_ERROR_TOO_LONG_BATCH_OPERATION;
    goto result;
  }

  ret = send_communicate_buffer(rdarm_cb, &node->connection, index, false);
  if (ret != RDARM_SUCCESS) {
    goto result;
  }

  pthread_spin_lock(&request->payload.batch_operation_request.lock);
  rdarm_complex_communicate_data *response = &node->connection.communicate_buf_array[request->replay_to];
  for (int i = 0; i < real_count; ++i) {
    op_reply[i].original_index= response->payload.batch_operation_reply[i].original_index;
    op_reply[i].result = response->payload.batch_operation_reply[i].result;
    if (response->payload.batch_operation_reply[i].result == RDARM_OP_SUCCESS) {
      zlog_debug(rdarm_cb->logger,
                 "%s| OPERATE SUCCESS: %lu",
                 node->address_str,
                 response->payload.batch_operation_reply[i].value);
      op_reply[i].value = response->payload.batch_operation_reply[i].value;
    } else {
      zlog_debug(rdarm_cb->logger,
                 "%s| OPERATE FAILED: %s",
                 node->address_str,
                 rdarm_operation_string(response->payload.batch_operation_reply[i].result));
    }
  }

  result:
  pthread_spin_destroy(&request->payload.operation_request.lock);
  memset(request, 0, sizeof(rdarm_complex_communicate_data));
  request->request_type = RDARM_REQUEST_TYPE_FREE;
  return ret;
}

int rdarm_reply_batch_operation_request(rdarm *rdarm_cb,
                                        rdarm_node *node,
                                        uint32_t replay_to,
                                        rdarm_batch_operation_reply *op_replay, uint16_t batch_size) {
  int index = get_free_communicate_buffer(&node->connection);
  if (index == -1) {
    return RDARM_ERROR_NO_FREE_COMMUNICATE_BUFFER;
  }
  int ret = 0;
  rdarm_complex_communicate_data *request = &node->connection.communicate_buf_array[index];
  request->request_type = RDARM_REQUEST_TYPE_BATCH_OPERATE_REPLY;
  request->replay_to = replay_to;
  for (int i = 0; i < batch_size; ++i) {
    request->payload.batch_operation_reply[i] = op_replay[i];
    request->payload_size += sizeof(rdarm_batch_operation_reply);
  }

  ret = send_communicate_buffer(rdarm_cb, &node->connection, index, true);
  if (ret != RDARM_SUCCESS) {
    memset(request, 0, sizeof(rdarm_complex_communicate_data));
    request->request_type = RDARM_REQUEST_TYPE_FREE;
  }
  return ret;
}