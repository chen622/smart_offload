/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#include <sys/time.h>
#include "rdarm_internal/net/server_worker.h"

static int request_handler(struct general_args *args, struct ibv_wc *wc) {
  int ret = 0;
//  struct timeval start, end;
//  int16_t request_type = 0;
//  gettimeofday(&start, NULL);

  uint32_t index = be32toh(wc->imm_data);
  rdarm_complex_communicate_data *buf = &args->connection->communicate_buf_array[index];
//  request_type = buf->request_type;
  zlog_debug(args->rdarm_cb->logger, "receive new message(0x%x) (type: %d)", buf->request_id, buf->request_type);
  switch (buf->request_type) {
    case RDARM_REQUEST_TYPE_JOIN: {
      zlog_info(args->rdarm_cb->logger,
                "%s|Server| NEW JOIN REQUEST",
                args->node->address_str);
      change_slot_owner(args->rdarm_cb->key_slots, &args->rdarm_cb->self, args->node);

      ret = rdarm_replay_join_request(args->rdarm_cb, args->node, buf->request_id, true);
      if (ret != RDARM_SUCCESS) {
        zlog_error(args->rdarm_cb->logger, "failed to replay join request: %s", rdarm_error_string(ret));
        break;
      }

      memset(buf, 0, sizeof(rdarm_complex_communicate_data));
      buf->request_type = RDARM_REQUEST_TYPE_FREE;
      ret = RDARM_SUCCESS;
      break;
    }
    case RDARM_REQUEST_TYPE_JOIN_REPLAY: {
      args->connection->communicate_buf_array[rdarm_decode_request_id_to_index(buf->replay_to)].replay_to = index;
      pthread_spin_unlock(&args->connection->communicate_buf_array[rdarm_decode_request_id_to_index(buf->replay_to)].payload.join_request.lock);
      ret = RDARM_SUCCESS;
      break;
    }
    case RDARM_REQUEST_TYPE_OPERATE: {
      zlog_debug(args->rdarm_cb->logger,
                 "%s| receive new operate request (type: %d)",
                 args->node->address_str,
                 buf->payload.operation_request.type);
      rdarm_operation_replay replay = {0};
      switch (buf->payload.operation_request.type) {
        case RDARM_OP_REQUEST_TYPE_SET_TUPLE_UINT64: {
          replay.result = rdarm_set_tuple_uint64(args->rdarm_cb,
                                                 (rdarm_five_tuple *) buf->payload.operation_request.key,
                                                 buf->payload.operation_request.value,
                                                 buf->payload.operation_request.table_id);
          break;
        }
        case RDARM_OP_REQUEST_TYPE_GET_TUPLE_UINT64: {
          replay.result = rdarm_get_tuple_uint64(args->rdarm_cb,
                                                 (rdarm_five_tuple *) buf->payload.operation_request.key,
                                                 &replay.value,
                                                 buf->payload.operation_request.table_id);
          break;
        }
        default: {
          zlog_error(args->rdarm_cb->logger, "unknown operation request type: %d", buf->payload.operation_request.type);
          memset(buf, 0, sizeof(rdarm_complex_communicate_data));
          buf->request_type = RDARM_REQUEST_TYPE_FREE;
          return RDARM_ERROR_UNKNOWN_OPERATION_TYPE;
        }
      }

      ret = rdarm_replay_operation_request(args->rdarm_cb, args->node, buf->request_id, &replay);
      memset(buf, 0, sizeof(rdarm_complex_communicate_data));
      buf->request_type = RDARM_REQUEST_TYPE_FREE;
      if (ret != RDARM_SUCCESS) {
        zlog_error(args->rdarm_cb->logger, "failed to replay operation request: %s", rdarm_error_string(ret));
        break;
      }
      ret = RDARM_SUCCESS;
      break;
    }
    case RDARM_REQUEST_TYPE_OPERATE_REPLAY: {
      args->connection->communicate_buf_array[rdarm_decode_request_id_to_index(buf->replay_to)].replay_to = index;
      pthread_spin_unlock(&args->connection->communicate_buf_array[rdarm_decode_request_id_to_index(buf->replay_to)].payload.operation_request.lock);
      ret = RDARM_SUCCESS;
      break;
    }
    case RDARM_REQUEST_TYPE_ASYNC_OPERATE: {
      zlog_debug(args->rdarm_cb->logger,
                 "%s| receive new async operate request (type: %d)",
                 args->node->address_str,
                 buf->payload.operation_request.type);
      rdarm_async_operation_replay replay = {0};
      switch (buf->payload.operation_request.type) {
        case RDARM_OP_REQUEST_TYPE_ADD_TUPLE_UINT64: {
          replay.result = rdarm_add_tuple_uint64(args->rdarm_cb,
                                                 (rdarm_five_tuple *) buf->payload.operation_request.key,
                                                 replay.value,
                                                 buf->payload.operation_request.table_id);
          break;
        }
        default: {
          zlog_error(args->rdarm_cb->logger, "unknown operation request type: %d", buf->payload.operation_request.type);
          memset(buf, 0, sizeof(rdarm_complex_communicate_data));
          buf->request_type = RDARM_REQUEST_TYPE_FREE;
          return RDARM_ERROR_UNKNOWN_OPERATION_TYPE;
        }
      }
      ret = RDARM_SUCCESS;
      if (replay.result != RDARM_OP_SUCCESS) {
        replay.type = buf->payload.operation_request.type;
        replay.table_id = buf->payload.operation_request.table_id;
        replay.value = buf->payload.operation_request.value;
        memcpy(&replay.key, &buf->payload.operation_request.key, RDARM_KEY_LEN);
        ret = rdarm_replay_async_operation_request(args->rdarm_cb, args->node, &replay);
        if (ret != RDARM_SUCCESS) {
          zlog_error(args->rdarm_cb->logger, "failed to replay async operation request: %s", rdarm_error_string(ret));
        }
      }
      memset(buf, 0, sizeof(rdarm_complex_communicate_data));
      buf->request_type = RDARM_REQUEST_TYPE_FREE;
      break;
    }
    case RDARM_REQUEST_TYPE_ASYNC_REPLAY: {
      if (buf->payload.async_operation_replay.result != RDARM_OP_SUCCESS) {
        zlog_error(args->rdarm_cb->logger,
                   "%s| async operation replay failed: %s",
                   args->node->address_str,
                   rdarm_operation_string(buf->payload.async_operation_replay.result));
      }
      memset(buf, 0, sizeof(rdarm_complex_communicate_data));
      buf->request_type = RDARM_REQUEST_TYPE_FREE;
      ret = RDARM_SUCCESS;
      break;
    }
    case RDARM_REQUEST_TYPE_BATCH_OPERATE: {
      zlog_debug(args->rdarm_cb->logger,
                 "%s| receive new batch operate request (type: %d)",
                 args->node->address_str,
                 buf->payload.batch_operation_request.type);
      rdarm_batch_operation_reply replies[buf->payload.batch_operation_request.amount];
      rdarm_five_tuple keys[buf->payload.batch_operation_request.amount];
      uint64_t values[buf->payload.batch_operation_request.amount];
      uint16_t table_ids[buf->payload.batch_operation_request.amount];
      int results[buf->payload.batch_operation_request.amount];

      switch (buf->payload.batch_operation_request.type) {
        case RDARM_OP_REQUEST_TYPE_GET_TUPLE_UINT64: {
          for (uint16_t i = 0; i < buf->payload.batch_operation_request.amount; ++i) {

            memcpy(&keys[i], buf->payload.batch_operation_request.operation_request[i].key, RDARM_KEY_LEN);
            table_ids[i] = buf->payload.batch_operation_request.operation_request[i].table_id;
          }
          ret = rdarm_get_tuple_uint64_with_batch(args->rdarm_cb,
                                                  keys,
                                                  values,
                                                  table_ids,
                                                  buf->payload.batch_operation_request.amount,
                                                  results);
          for (uint16_t i = 0; i < buf->payload.batch_operation_request.amount; ++i) {
            replies[i].original_index = buf->payload.batch_operation_request.operation_request[i].original_index;
            if (ret == RDARM_OP_SUCCESS) {
              replies[i].result = results[i];
              replies[i].value = values[i];
            } else {
              replies[i].result = ret;
            }
          }
          break;
        }
        default: {
          zlog_error(args->rdarm_cb->logger, "unknown operation request type: %d", buf->payload.operation_request.type);
          memset(buf, 0, sizeof(rdarm_complex_communicate_data));
          buf->request_type = RDARM_REQUEST_TYPE_FREE;
          return RDARM_ERROR_UNKNOWN_OPERATION_TYPE;
        }
      }

      ret = rdarm_reply_batch_operation_request(args->rdarm_cb,
                                                args->node,
                                                buf->request_id,
                                                replies,
                                                buf->payload.batch_operation_request.amount);
      memset(buf, 0, sizeof(rdarm_complex_communicate_data));
      buf->request_type = RDARM_REQUEST_TYPE_FREE;
      if (ret != RDARM_SUCCESS) {
        zlog_error(args->rdarm_cb->logger, "failed to replay operation request: %s", rdarm_error_string(ret));
        break;
      }
      ret = RDARM_SUCCESS;
      break;
    }
    case RDARM_REQUEST_TYPE_BATCH_OPERATE_REPLY: {
      args->connection->communicate_buf_array[rdarm_decode_request_id_to_index(buf->replay_to)].replay_to = index;
      pthread_spin_unlock(&args->connection->communicate_buf_array[rdarm_decode_request_id_to_index(buf->replay_to)].payload.batch_operation_request.lock);
      ret = RDARM_SUCCESS;
      break;
    }
    default:zlog_error(args->rdarm_cb->logger, "unknown request type(imm: %d): %d", index, buf->request_type);
      ret = RDARM_ERROR_UNKNOWN_REQUEST_TYPE;
      break;
  }

//  gettimeofday(&end, NULL);
//  if (end.tv_usec - start.tv_usec > 10) {
//    zlog_info(args->rdarm_cb->logger, "high delay request(%d) handler: %ld", request_type, end.tv_usec - start.tv_usec);
//  }
  return ret;
}

void *message_worker_thread(void *args) {
  pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
  pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL);

  struct rdarm_node *node = ((struct general_args *) args)->node;
  struct rdarm *rdarm_cb = ((struct general_args *) args)->rdarm_cb;
  struct rdarm_connection *connection = ((struct general_args *) args)->connection;

  int ret = 0;
  struct ibv_wc wc;
  struct ibv_cq *ev_cq;
  void *ev_ctx;


  while (1) {
    pthread_testcancel();
    ret = ibv_get_cq_event(connection->comp_channel, &ev_cq, &ev_ctx);
    pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);
    if (ret) {
      zlog_error(rdarm_cb->logger, "Failed to get cq event!\n");
      pthread_exit(NULL);
    }
    ret = ibv_req_notify_cq(connection->cq, 0);
    if (ret) {
      zlog_error(rdarm_cb->logger, "Failed to set notify!\n");
      pthread_exit(NULL);
    }
    while ((ret = ibv_poll_cq(connection->cq, 1, &wc)) == 1) {
      if (ret < 0) {
        zlog_error(rdarm_cb->logger, "failed to poll CQ: %s", strerror(errno));
        ret = RDARM_ERROR_CQ_EVENT;
        break;
      } else if (ret == 0) {
        continue;
      }
      zlog_debug(rdarm_cb->logger,
                 "%s|%s| New CQ Event(0x%lx)",
                 node->address_str,
                 rdarm_connection_type_to_string(connection->type),
                 wc.wr_id);
      if (wc.status != IBV_WC_SUCCESS) {
        zlog_error(rdarm_cb->logger, "%s|%s| cq event is error: %s\n", node->address_str,
                   rdarm_connection_type_to_string(connection->type), ibv_wc_status_str(wc.status));
        continue;
      }
      if (wc.opcode == IBV_WC_RECV_RDMA_WITH_IMM) { // Received request from peer.
        //zlog_debug(rdarm_cb->logger, "received RDMA write with imm");
        ret = post_receive_work_request(rdarm_cb, connection);
        if (ret != RDARM_SUCCESS) {
          zlog_error(rdarm_cb->logger, "failed to post receive work request: %s", strerror(errno));
          break;
        }
        ret = request_handler(args, &wc);
        if (ret != RDARM_SUCCESS) {
          zlog_error(rdarm_cb->logger, "failed to handle RDMA write with imm: %s", rdarm_error_string(ret));
          continue;
        }

      } else if (wc.opcode == IBV_WC_RDMA_WRITE) { // Finish Send request to peer.
        if (node->connection.connection_state == RDARM_CONNECTION_STATE_CONNECTED_AND_READY) { // Send request to peer.
          struct rdarm_complex_communicate_data
              *request = &connection->communicate_buf_array[rdarm_decode_request_id_to_index(wc.wr_id)];
          zlog_debug(rdarm_cb->logger, "success write request (0x%lx) (type: %d)", wc.wr_id, request->request_type);
          if (wc.wr_id == 0) {
            zlog_error(rdarm_cb->logger,
                       "%s|%s| wc.wr_id is 0",
                       node->address_str,
                       rdarm_connection_type_to_string(connection->type));
          }
          if (request->request_type == RDARM_REQUEST_TYPE_FREE) {
            zlog_error(rdarm_cb->logger,
                       "%s|%s| WR 0x%lx request type is RDARM_REQUEST_TYPE_FREE",
                       node->address_str,
                       rdarm_connection_type_to_string(connection->type), wc.wr_id);
          }
          if (rdarm_is_send_wr(wc.wr_id)) { // Send request actively.
            if (request->request_type < RDARM_REQUEST_TYPE_BLOCKING) { // Non-blocking request.
              pthread_spin_unlock(&request->payload.operation_request.lock);
            }
          } else { // Replay request.
            memset(request, 0, sizeof(rdarm_complex_communicate_data));
            request->request_type = RDARM_REQUEST_TYPE_FREE;
          }
        } else { // Send pre allocate memory buffer address to peer.
          sem_post(&connection->sem);
        }
        continue;
      } else if (wc.opcode == IBV_WC_RDMA_READ) {
//        rdarm_cb->key_slots[rdarm_decode_read_request_id_to_index(wc.wr_id)].state = SLOT_STABLE;
        sem_post(&connection->sem);
        continue;
      } else {
        zlog_error(rdarm_cb->logger, "unknown opcode: %d", wc.opcode);
        ret = RDARM_ERROR_UNKNOWN_RDMA_OP_CODE;
        break;
      }
    }
    ibv_ack_cq_events(connection->cq, 1);
    if (ret) {
      zlog_error(rdarm_cb->logger, "Failed to handle cq event!\n");
      pthread_exit(NULL);
    }
    pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
  }
}