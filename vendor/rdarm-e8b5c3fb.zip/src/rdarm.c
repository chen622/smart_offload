/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#include <arpa/inet.h>
#include <unistd.h>
#include <sys/time.h>

#include "rdarm.h"
#include "rdarm_internal/net/rdarm_net.h"

int remote_access = 0;

int rdarm_init(rdarm **rdarm_cb,
               const char *self_ip,
               const char *peer_ip) {
  int ret = 0;
  rdarm *cb = 0;
  rdarm_node *peer_node = 0;

//  ret = zlog_init(log_path);
//  if (ret) {
//    printf("failed to find the configure file of zlog\n");
//    return RDARM_ERROR_INVALID_PARAMETER;
//  }

  *rdarm_cb = calloc(1, sizeof(rdarm));
  if (!*rdarm_cb) {
    printf("failed to allocate memory for rdarm\n");
    return RDARM_ERROR_FAILED_TO_ALLOC_MEMORY;
  }

  cb = *rdarm_cb;

  // initialize the logger
  cb->logger = zlog_get_category("rdarm");
  if (!cb->logger) {
    printf("failed to initialize logger\n");
    ret = RDARM_ERROR_INVALID_PARAMETER;
    goto err;
  }

  // initialize the slots and tables
  ret = rdarm_store_init(&cb->key_slots, &cb->self);
  if (ret != RDARM_SUCCESS) {
    zlog_error(cb->logger, "failed to initialize the store of rdarm");
    ret = RDARM_ERROR_UNKNOWN;
    goto err;
  }

  for (uint16_t i = 0; i < RDARM_SLOT_NUM; ++i) {
    for (uint16_t j = 0; j < RDARM_HASH_TABLE_NUM; ++j) {
      pthread_rwlock_init(&cb->table_lock[i][j], NULL);
    }
  }

  pthread_rwlock_init(&cb->self.state_lock, NULL);

  if (strcmp(self_ip, "0.0.0.0") != 0) {
    ret = inet_pton(AF_INET, self_ip, (void *) &cb->self.address.sin_addr);
    if (ret == 0) {
      zlog_error(cb->logger, "self ip address do not support IPv6 address");
      ret = RDARM_ERROR_INVALID_PARAMETER;
      goto err;
    } else if (ret < 0) {
      zlog_error(cb->logger, "failed to parse the ip address of self");
      ret = RDARM_ERROR_INVALID_PARAMETER;
      goto err;
    }
    cb->self.address.sin_port = RDARM_PORT;
    cb->self.address.sin_family = AF_INET;
    memcpy(cb->self.address_str, self_ip, INET_ADDRSTRLEN);

    ret = rdarm_net_init(cb);
    if (ret != RDARM_SUCCESS) {
      zlog_error(cb->logger, "failed to initialize the net of rdarm");
      goto err;
    }

    cb->self.state = RDARM_NODE_STATE_LISTENING;

    if (strcmp(peer_ip, "0.0.0.0") != 0) { // Connect to the default peer
      peer_node = calloc(1, sizeof(rdarm_node));
      memcpy(peer_node->address_str, peer_ip, INET_ADDRSTRLEN);
      ret = inet_pton(AF_INET, peer_ip, (void *) &peer_node->address.sin_addr);
      if (ret == 0) {
        free(peer_node);
        zlog_error(cb->logger, "peer ip address do not support IPv6 address");
        ret = RDARM_ERROR_INVALID_PARAMETER;
        goto err2;
      } else if (ret < 0) {
        free(peer_node);
        zlog_error(cb->logger, "failed to parse the ip address of peer");
        ret = RDARM_ERROR_INVALID_PARAMETER;
        goto err2;
      }
      peer_node->address.sin_port = RDARM_PORT;
      peer_node->address.sin_family = AF_INET;

      HASH_ADD_STR(cb->others, address_str, peer_node);
      struct general_args *args = calloc(1, sizeof(struct general_args));
      args->rdarm_cb = cb;
      args->node = peer_node;
      args->connection = &peer_node->connection;
      ret = connect_node(args);
      if (ret != RDARM_SUCCESS) {
        HASH_DEL(cb->others, peer_node);
        free(peer_node);
        zlog_error(cb->logger, "failed to connect to peer");
        goto err2;
      }
      cb->self.state = RDARM_NODE_STATE_MIGRATING;
      ret = rdarm_send_join_request(cb, peer_node);
      if (ret != RDARM_SUCCESS) {
        zlog_error(cb->logger, "failed to join the cluster");
        goto err3;
      }
    }
  } else {
    memcpy(cb->self.address_str, self_ip, INET_ADDRSTRLEN);
    zlog_info(cb->logger, "rdarm is running in standalone mode");
  }
  cb->self.state = RDARM_NODE_STATE_WORKING;

  zlog_info(cb->logger, "Rdarm is running!");
  return RDARM_SUCCESS;
  err3: // Do not need free peer_node.
  destroy_connection(&peer_node->connection);
  err2:
  rdarm_net_stop(cb);
  err:
  free(cb);
  return ret;
}

int rdarm_destroy(rdarm *rdarm_cb) {
  int ret = 0;

  if (strcmp(rdarm_cb->self.address_str, "0.0.0.0") != 0) {
    ret = rdarm_net_stop(rdarm_cb);
    if (ret != RDARM_SUCCESS) {
      zlog_error(rdarm_cb->logger, "failed to stop network of rdarm");
    }
  }

  for (uint16_t i = 0; i < RDARM_SLOT_NUM; ++i) {
    for (uint16_t j = 0; j < RDARM_HASH_TABLE_NUM; ++j) {
      pthread_rwlock_unlock(&rdarm_cb->table_lock[i][j]);
      pthread_rwlock_destroy(&rdarm_cb->table_lock[i][j]);
    }
  }

  ret = rdarm_store_destroy(rdarm_cb->key_slots);
  if (ret != RDARM_SUCCESS) {
    zlog_error(rdarm_cb->logger, "failed to destroy the store of rdarm");
  }

  free(rdarm_cb);
  return RDARM_SUCCESS;
}

/**
 * @brief Check the key and value before execute operation.
 */
static inline int check_key_value(zlog_category_t *logger,
                                  uint16_t table_id,
                                  void *key,
                                  size_t key_len,
                                  bool is_tuple,
                                  void *value,
                                  size_t value_len,
                                  enum value_type value_type) {
  if (table_id >= RDARM_HASH_TABLE_NUM) {
    zlog_info(logger, "invalid table id: %d", table_id);
    return RDARM_OP_INVALID_TABLE_ID;
  }

  if (is_tuple) {
    if (key == NULL) {
      zlog_info(logger, "invalid key");
      return RDARM_OP_INVALID_KEY_OR_VALUE;
    }
  } else {
    if (key_len == 0) {
      zlog_info(logger, "key is empty");
      return RDARM_OP_INVALID_KEY_OR_VALUE;
    }

    if (key_len > RDARM_KEY_LEN) {
      zlog_info(logger, "key is too long");
      return RDARM_OP_INVALID_KEY_LENGTH;
    }
  }

  if (value_type == VALUE_STRING) {
    if (value_len == 0) {
      zlog_info(logger, "value is empty");
      return RDARM_OP_INVALID_KEY_OR_VALUE;
    }
  }

  return RDARM_OP_SUCCESS;
}

static inline uint64_t get_hash_result(void *key, size_t key_len) {
  if (key_len > 16) {
    return XXH3_128bits_withSeed(key, 16, SLOT_KEY_SEED).high64;
  } else {
    return XXH3_128bits_withSeed(key, key_len, SLOT_KEY_SEED).high64;
  }
}

int rdarm_set_string_string(rdarm *rdarm_cb, char *key, char *value, uint16_t table_id) {
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    return RDARM_OP_NOT_READY;
  }
  size_t key_len = strlen(key);
  size_t value_len = strlen(value);
  int ret = 0;
  if ((ret = check_key_value(rdarm_cb->logger, table_id, key, key_len, false, value, value_len, VALUE_STRING))
      != RDARM_OP_SUCCESS) {
    return ret;
  }

  uint16_t slot_index = get_hash_result(key, key_len) % RDARM_SLOT_NUM;
  pthread_rwlock_rdlock(&rdarm_cb->self.state_lock);
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return RDARM_OP_NOT_READY;
  }
  pthread_rwlock_wrlock(&rdarm_cb->table_lock[slot_index][table_id]);
  ret = save_string_value(&rdarm_cb->key_slots[get_hash_result(key, key_len) % RDARM_SLOT_NUM],
                          table_id,
                          key,
                          key_len,
                          value,
                          value_len);
  pthread_rwlock_unlock(&rdarm_cb->table_lock[slot_index][table_id]);
  pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
  return ret;
}

int rdarm_get_string_string(rdarm *rdarm_cb, char *key, char **value, uint16_t table_id) {
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    return RDARM_OP_NOT_READY;
  }
  size_t key_len = strlen(key);
  int ret = 0;
  if ((ret = check_key_value(rdarm_cb->logger, table_id, key, key_len, false, NULL, 0, VALUE_EMPTY))
      != RDARM_OP_SUCCESS) {
    return ret;
  }

  uint16_t slot_index = get_hash_result(key, key_len) % RDARM_SLOT_NUM;
  pthread_rwlock_rdlock(&rdarm_cb->self.state_lock);
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return RDARM_OP_NOT_READY;
  }
  pthread_rwlock_rdlock(&rdarm_cb->table_lock[slot_index][table_id]);
  ret = load_string_value(&rdarm_cb->key_slots[get_hash_result(key, key_len) % RDARM_SLOT_NUM],
                          table_id,
                          key,
                          key_len,
                          value);
  pthread_rwlock_unlock(&rdarm_cb->table_lock[slot_index][table_id]);
  pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
  return ret;
}

int rdarm_lpush_tuple_uint64(rdarm *rdarm_cb, rdarm_five_tuple *key, uint64_t value, uint16_t table_id) {

  int ret = 0;
  if ((ret = check_key_value(rdarm_cb->logger, table_id, key, sizeof(rdarm_five_tuple), true, NULL, 0, VALUE_EMPTY))
      != RDARM_OP_SUCCESS) {
    return ret;
  }

  uint16_t slot_index = get_hash_result(key, sizeof(rdarm_five_tuple)) % RDARM_SLOT_NUM;
  pthread_rwlock_rdlock(&rdarm_cb->self.state_lock);
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return RDARM_OP_NOT_READY;
  }
  pthread_rwlock_wrlock(&rdarm_cb->table_lock[slot_index][table_id]);
  ret = lpush_uint64_list(&rdarm_cb->key_slots[get_hash_result(key, sizeof(rdarm_five_tuple)) % RDARM_SLOT_NUM],
                          table_id,
                          key,
                          sizeof(rdarm_five_tuple),
                          value);
  pthread_rwlock_unlock(&rdarm_cb->table_lock[slot_index][table_id]);
  pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
  return ret;
}

int rdarm_lpop_tuple_uint64(rdarm *rdarm_cb, rdarm_five_tuple *key, uint64_t *value, uint16_t table_id) {
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    return RDARM_OP_NOT_READY;
  }
  int ret = 0;
  if ((ret = check_key_value(rdarm_cb->logger, table_id, key, sizeof(rdarm_five_tuple), true, NULL, 0, VALUE_EMPTY))
      != RDARM_OP_SUCCESS) {
    return ret;
  }

  uint16_t slot_index = get_hash_result(key, sizeof(rdarm_five_tuple)) % RDARM_SLOT_NUM;
  pthread_rwlock_rdlock(&rdarm_cb->self.state_lock);
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return RDARM_OP_NOT_READY;
  }
  pthread_rwlock_wrlock(&rdarm_cb->table_lock[slot_index][table_id]);
  ret = lpop_uint64_list(&rdarm_cb->key_slots[get_hash_result(key, sizeof(rdarm_five_tuple)) % RDARM_SLOT_NUM],
                         table_id,
                         key,
                         sizeof(rdarm_five_tuple),
                         value);
  pthread_rwlock_unlock(&rdarm_cb->table_lock[slot_index][table_id]);
  pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
  return ret;
}

int rdarm_set_tuple_uint64(rdarm *rdarm_cb, rdarm_five_tuple *key, uint64_t value, uint16_t table_id) {
  int ret = 0;
  if ((ret = check_key_value(rdarm_cb->logger, table_id, key, sizeof(rdarm_five_tuple), true, NULL, 0, VALUE_EMPTY))
      != RDARM_OP_SUCCESS) {
    return ret;
  }

  uint16_t slot_index = get_hash_result(key, sizeof(rdarm_five_tuple)) % RDARM_SLOT_NUM;
  pthread_rwlock_rdlock(&rdarm_cb->self.state_lock);
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return RDARM_OP_NOT_READY;
  }
  struct key_slot *slot = &rdarm_cb->key_slots[slot_index];
  if (slot->owner == &rdarm_cb->self || slot->owner == NULL) {
    pthread_rwlock_wrlock(&rdarm_cb->table_lock[slot_index][table_id]);
    ret = save_uint64_value(slot,
                            table_id,
                            key,
                            sizeof(rdarm_five_tuple),
                            value);
    pthread_rwlock_unlock(&rdarm_cb->table_lock[slot_index][table_id]);
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return ret;
  } else {
    remote_access++;
    rdarm_operation_request request = {
        .type = RDARM_OP_REQUEST_TYPE_SET_TUPLE_UINT64,
        .value = value,
        .slot_index =slot_index,
        .table_id = table_id,
    };
    memcpy(request.key, key, sizeof(rdarm_five_tuple));
    rdarm_operation_replay replay = {0};
    ret = rdarm_send_operation_request(rdarm_cb, slot->owner, &request, &replay);
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    if (ret == RDARM_SUCCESS || ret == RDARM_ERROR_REMOTE_OPERATION) {
      return replay.result;
    } else {
      return RDARM_OP_FAILED_TO_SEND_REMOTE;
    }
  }
}

int rdarm_add_tuple_uint64(rdarm *rdarm_cb, rdarm_five_tuple *key, uint64_t value, uint16_t table_id) {
  int ret = 0;
  if ((ret = check_key_value(rdarm_cb->logger, table_id, key, sizeof(rdarm_five_tuple), true, NULL, 0, VALUE_EMPTY))
      != RDARM_OP_SUCCESS) {
    return ret;
  }

  uint16_t slot_index = get_hash_result(key, sizeof(rdarm_five_tuple)) % RDARM_SLOT_NUM;
  pthread_rwlock_rdlock(&rdarm_cb->self.state_lock);
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return RDARM_OP_NOT_READY;
  }
  struct key_slot *slot = &rdarm_cb->key_slots[slot_index];
  if (slot->owner == &rdarm_cb->self || slot->owner == NULL) {
    pthread_rwlock_wrlock(&rdarm_cb->table_lock[slot_index][table_id]);
    ret = add_uint64_value(slot,
                           table_id,
                           key,
                           sizeof(rdarm_five_tuple),
                           value);
    pthread_rwlock_unlock(&rdarm_cb->table_lock[slot_index][table_id]);
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return ret;
  } else {
    remote_access++;
    rdarm_operation_request request = {
        .type = RDARM_OP_REQUEST_TYPE_ADD_TUPLE_UINT64,
        .value = value,
        .slot_index =slot_index,
        .table_id = table_id,
    };
    memcpy(request.key, key, sizeof(rdarm_five_tuple));
    ret = rdarm_send_async_operation_request(rdarm_cb, slot->owner, &request);
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    if (ret == RDARM_SUCCESS) {
      return RDARM_OP_SUCCESS;
    } else {
      return RDARM_OP_FAILED_TO_SEND_REMOTE;
    }
  }
}

int rdarm_get_tuple_uint64(rdarm *rdarm_cb, rdarm_five_tuple *key, uint64_t *value, uint16_t table_id) {
  int ret = 0;
  if ((ret = check_key_value(rdarm_cb->logger, table_id, key, sizeof(rdarm_five_tuple), true, NULL, 0, VALUE_EMPTY))
      != RDARM_OP_SUCCESS) {
    return ret;
  }

  uint16_t slot_index = get_hash_result(key, sizeof(rdarm_five_tuple)) % RDARM_SLOT_NUM;
  pthread_rwlock_rdlock(&rdarm_cb->self.state_lock);
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return RDARM_OP_NOT_READY;
  }
  struct key_slot *slot = &rdarm_cb->key_slots[slot_index];
  if (slot->owner == &rdarm_cb->self || slot->owner == NULL) {
    pthread_rwlock_rdlock(&rdarm_cb->table_lock[slot_index][table_id]);
    ret = load_uint64_value(slot,
                            table_id,
                            key,
                            sizeof(rdarm_five_tuple),
                            value);
    pthread_rwlock_unlock(&rdarm_cb->table_lock[slot_index][table_id]);
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return ret;
  } else {
    remote_access++;
    rdarm_operation_request request = {
        .type = RDARM_OP_REQUEST_TYPE_GET_TUPLE_UINT64,
        .slot_index =slot_index,
        .table_id = table_id,
    };
    memcpy(request.key, key, sizeof(rdarm_five_tuple));
    rdarm_operation_replay replay = {0};
    ret = rdarm_send_operation_request(rdarm_cb, slot->owner, &request, &replay);
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    if (ret == RDARM_SUCCESS || ret == RDARM_ERROR_REMOTE_OPERATION) {
      *value = replay.value;
      return replay.result;
    } else {
      return RDARM_OP_FAILED_TO_SEND_REMOTE;
    }
  }
}

int rdarm_get_tuple_uint64_with_batch(rdarm *rdarm_cb,
                                      rdarm_five_tuple keys[],
                                      uint64_t values[],
                                      uint16_t table_ids[],
                                      uint16_t batch_size,
                                      int results[]) {
  int ret = 0;
  uint16_t has_result = 0;
  uint16_t slot_index = 0;
  struct key_slot *slot = NULL;
  struct rdarm_node *remote_node = NULL;
  rdarm_operation_request request[batch_size];
  rdarm_batch_operation_reply reply[batch_size];

  for (uint16_t i = 0; i < batch_size; ++i) {
    results[i] = RDARM_OP_BATCH_PROCESSING;
    request[i].type = RDARM_OP_REQUEST_TYPE_UNKNOWN;
    if ((ret = check_key_value(rdarm_cb->logger,
                               table_ids[i],
                               &keys[i],
                               sizeof(rdarm_five_tuple),
                               true,
                               NULL,
                               0,
                               VALUE_EMPTY))
        != RDARM_OP_SUCCESS) {
      results[i] = ret;
      has_result++;
    }
  }
  if (has_result == batch_size) {
    return RDARM_OP_SUCCESS;
  }

  pthread_rwlock_rdlock(&rdarm_cb->self.state_lock);
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return RDARM_OP_NOT_READY;
  }

  for (uint16_t i = 0; i < batch_size; ++i) {
    if (results[i] != RDARM_OP_BATCH_PROCESSING) {
      continue;
    }
    slot_index = get_hash_result(&keys[i], sizeof(rdarm_five_tuple)) % RDARM_SLOT_NUM;
    slot = &rdarm_cb->key_slots[slot_index];
    if (slot->owner == &rdarm_cb->self || slot->owner == NULL) {
      pthread_rwlock_rdlock(&rdarm_cb->table_lock[slot_index][table_ids[i]]);
      ret = load_uint64_value(slot,
                              table_ids[i],
                              &keys[i],
                              sizeof(rdarm_five_tuple),
                              &values[i]);
      results[i] = ret;
      has_result++;
      pthread_rwlock_unlock(&rdarm_cb->table_lock[slot_index][table_ids[i]]);
    } else {
      remote_access++;
      remote_node = slot->owner;
      request[i].type = RDARM_OP_REQUEST_TYPE_GET_TUPLE_UINT64;
      request[i].table_id = table_ids[i];
      memcpy(request[i].key, &keys[i], sizeof(rdarm_five_tuple));
    }
  }
  if (has_result == batch_size || remote_node == NULL) {
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return RDARM_OP_SUCCESS;
  }

  ret = rdarm_send_batch_operation_request(rdarm_cb, remote_node, request, reply, batch_size);

//  ret = rdarm_send_operation_request(rdarm_cb, slot->owner, request, replay);
  pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
  if (ret == RDARM_SUCCESS) {
    for (uint16_t i = 0; i < batch_size - has_result; ++i) {
      if (reply[i].result == RDARM_OP_SUCCESS) {
        results[reply[i].original_index] = reply[i].result;
        values[reply[i].original_index] = reply[i].value;
      } else {
        results[reply[i].original_index] = reply[i].result;
      }
    }
    return RDARM_SUCCESS;
  } else {
    for (uint16_t i = 0; i < batch_size; ++i) {
      if (results[i] == RDARM_OP_BATCH_PROCESSING) {
        results[i] = ret;
      }
    }
    return RDARM_OP_FAILED_TO_SEND_REMOTE;
  }

}

int rdarm_get_tuple_uint64_with_cache(rdarm *rdarm_cb, rdarm_five_tuple *key, uint64_t *value, uint16_t table_id) {
  int ret = 0;
  if ((ret = check_key_value(rdarm_cb->logger, table_id, key, sizeof(rdarm_five_tuple), true, NULL, 0, VALUE_EMPTY))
      != RDARM_OP_SUCCESS) {
    return ret;
  }

  uint16_t slot_index = get_hash_result(key, sizeof(rdarm_five_tuple)) % RDARM_SLOT_NUM;
  pthread_rwlock_rdlock(&rdarm_cb->self.state_lock);
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return RDARM_OP_NOT_READY;
  }
  struct key_slot *slot = &rdarm_cb->key_slots[slot_index];
  if (slot->owner == &rdarm_cb->self || slot->owner == NULL) {
    pthread_rwlock_rdlock(&rdarm_cb->table_lock[slot_index][table_id]);
    ret = load_uint64_value(slot,
                            table_id,
                            key,
                            sizeof(rdarm_five_tuple),
                            value);
    pthread_rwlock_unlock(&rdarm_cb->table_lock[slot_index][table_id]);
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return ret;
  } else {
    pthread_rwlock_rdlock(&rdarm_cb->table_lock[slot_index][table_id]);
    ret = load_uint64_value_cache(slot,
                                  table_id,
                                  key,
                                  sizeof(rdarm_five_tuple),
                                  value);
    if (ret == RDARM_OP_SUCCESS) {
      pthread_rwlock_unlock(&rdarm_cb->table_lock[slot_index][table_id]);
//      zlog_info(rdarm_cb->logger, "load from cache");
      return RDARM_OP_SUCCESS;
    }
    pthread_rwlock_unlock(&rdarm_cb->table_lock[slot_index][table_id]);

    remote_access++;
    rdarm_operation_request request = {
        .type = RDARM_OP_REQUEST_TYPE_GET_TUPLE_UINT64,
        .slot_index =slot_index,
        .table_id = table_id,
    };
    memcpy(request.key, key, sizeof(rdarm_five_tuple));
    rdarm_operation_replay replay = {0};
    ret = rdarm_send_operation_request(rdarm_cb, slot->owner, &request, &replay);
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    if (ret == RDARM_SUCCESS || ret == RDARM_ERROR_REMOTE_OPERATION) {
      *value = replay.value;
      if (replay.result == RDARM_OP_SUCCESS) {

        pthread_rwlock_wrlock(&rdarm_cb->table_lock[slot_index][table_id]);
        ret = save_uint64_value_cache(slot,
                                      table_id,
                                      key,
                                      sizeof(rdarm_five_tuple),
                                      *value);
        pthread_rwlock_unlock(&rdarm_cb->table_lock[slot_index][table_id]);
//        if (ret == RDARM_OP_SUCCESS) {
//          zlog_info(rdarm_cb->logger, "save a cache");
//        }
      }
      return replay.result;
    } else {
      return RDARM_OP_FAILED_TO_SEND_REMOTE;
    }
  }
}

int rdarm_set_string_uint64(rdarm *rdarm_cb, char *key, uint64_t value, uint16_t table_id) {
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    return RDARM_OP_NOT_READY;
  }
  int ret = 0;
  size_t key_len = strlen(key);
  if ((ret = check_key_value(rdarm_cb->logger, table_id, key, key_len, false, NULL, 0, VALUE_EMPTY))
      != RDARM_SUCCESS) {
    return ret;
  }

  uint16_t slot_index = get_hash_result(key, key_len) % RDARM_SLOT_NUM;
  pthread_rwlock_rdlock(&rdarm_cb->self.state_lock);
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return RDARM_OP_NOT_READY;
  }
  pthread_rwlock_wrlock(&rdarm_cb->table_lock[slot_index][table_id]);
  ret = save_uint64_value(&rdarm_cb->key_slots[slot_index],
                          table_id,
                          key,
                          sizeof(rdarm_five_tuple),
                          value);
  pthread_rwlock_unlock(&rdarm_cb->table_lock[slot_index][table_id]);
  pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
  return ret;
}

int rdarm_get_string_uint64(rdarm *rdarm_cb, char *key, uint64_t *value, uint16_t table_id) {
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    return RDARM_OP_NOT_READY;
  }
  int ret = 0;
  size_t key_len = strlen(key);
  if ((ret = check_key_value(rdarm_cb->logger, table_id, key, sizeof(rdarm_five_tuple), false, NULL, 0, VALUE_EMPTY))
      != RDARM_SUCCESS) {
    return ret;
  }

  uint16_t slot_index = get_hash_result(key, key_len) % RDARM_SLOT_NUM;
  pthread_rwlock_rdlock(&rdarm_cb->self.state_lock);
  if (rdarm_cb->self.state != RDARM_NODE_STATE_WORKING) {
    pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
    return RDARM_OP_NOT_READY;
  }
  pthread_rwlock_rdlock(&rdarm_cb->table_lock[slot_index][table_id]);
  ret = load_uint64_value(&rdarm_cb->key_slots[get_hash_result(key, key_len) % RDARM_SLOT_NUM],
                          table_id,
                          key,
                          sizeof(rdarm_five_tuple),
                          value);
  pthread_rwlock_unlock(&rdarm_cb->table_lock[slot_index][table_id]);
  pthread_rwlock_unlock(&rdarm_cb->self.state_lock);
  return ret;
}