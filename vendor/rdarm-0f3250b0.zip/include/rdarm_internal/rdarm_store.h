/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#ifndef RDARM_INCLUDE_RDARM_INTERNAL_RDARM_STORE_H_
#define RDARM_INCLUDE_RDARM_INTERNAL_RDARM_STORE_H_

#include "rdarm_common.h"
#include "rdarm_internal/rdarm_node.h"

#include <sds.h>
#include <xxhash.h>
#include <utlist.h>

/**
 * @brief The value type of a entry.
 */
enum value_type {
  VALUE_EMPTY = 0,
  VALUE_SDS,
  VALUE_UINT64_LIST,
  VALUE_UINT64,
  VALUE_LONG,
  VALUE_DOUBLE,
  VALUE_STRING,
  VALUE_UINT64_CACHE
};

typedef struct uint64_node {
  uint64_t value;
  struct uint64_node *next, *prev;
} uint64_node;

#pragma pack(4)
/**
 * @brief The structure used to save a key-value pair.
 *
 * @verbatim
 *      |    128 bit    ||32 bit||32 bit||  64 bit |
 *      [......key......][.type.][.next.][..value..]
 * @endverbatim
 */
typedef struct dict_entry {
  union {
    char str[RDARM_KEY_LEN];
    struct rdarm_five_tuple tuple;
  } key;
  enum value_type type;
  uint32_t next_index;
  union {
    void *val;
    sds sds;
    uint64_node *uint64_list;
    uint64_t u64;
    int64_t s64;
    double f64;
    char str[8];
  } value; /**< The value of the key-value pair and it can be string, number, or pointer. */
//  struct dict_entry *next; /**< The pointer to next entry. */
} dict_entry;
#pragma pack()

/**
 * @brief The hash table used to save key-value pairs.
 */
typedef struct dict_hash_table {
  dict_entry entries[RDARM_BUCKET_NUM]; /**< The array to save the key-value pairs. */
  dict_entry addition_entries[RDARM_ADDITION_BUCKET_NUM]; /**< The array to save the collision key-value pairs. */
  uint64_t size;
  uint64_t used;
} dict_hash_table;

/**
 * @brief The states of slot.
 */
enum slot_state {
  SLOT_PREPARING = 0,
  SLOT_STABLE,
  SLOT_MIGRATE_IN,
  SLOT_MIGRATE_OUT,
  SLOT_EXITING
};

/**
 * @brief Slot is the minimum unit to determine ownership.
 */
typedef struct key_slot {
  int slot_id;
  enum slot_state state;
  rdarm_node *owner;
  dict_hash_table hash_tables[RDARM_HASH_TABLE_NUM]; /**< The array to save hash tables. */
} key_slot;

/**
 * @brief Initialize the hash tables.
 *
 * @param key_slots The slot array to save all hash tables.
 * @param init_owner The init owner of the slot.
 *
 * @return The result of initialization.
 */
int rdarm_store_init(key_slot **key_slots, rdarm_node *init_owner);

/**
 * @brief Destroy the hash tables.
 *
 * @param key_slots The slot array to save all hash tables.
 * @return The result of destruction.
 */
int rdarm_store_destroy(key_slot *key_slots);

/**
 * Rehash the slots into nodes.
 *
 * @param key_slots The slots to rehash.
 * @param self The self node.
 * @param others The connected node.
 *
 * @return
 */
int rehash_slot(key_slot *key_slots, rdarm_node *self, rdarm_node *others);

/**
 * Change the owner of some slots when new node join in.
 *
 * @param key_slots The slots to rehash.
 * @param self The self node.
 * @param changer The node to join or leave.
 *
 * @return
 */
int change_slot_owner(key_slot *key_slots, rdarm_node *self, rdarm_node *changer);

/**
 * @brief Save a string value.
 *
 * @param key_slot The slot of this key.
 * @param table_id The table id which user select.
 * @param key The key of this value.
 * @param key_len The length of key.
 * @param value The value to save.
 * @param value_len The string length of value.
 *
 * @return The result of saving.
 */
int save_string_value(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, char *value, size_t value_len);

/**
 * @brief Load a string value.
 *
 * @param key_slot The slot of this key.
 * @param table_id The table id which user select.
 * @param key The key of this value.
 * @param key_len The length of key.
 * @param value The value will be saved to.
 *
 * @return The result of loading.
 */
int load_string_value(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, char **value);

/**
 * @brief Push a uint64 value into a list from left side.
 *
 * @param key_slot The slot of this key.
 * @param table_id The table id which user select.
 * @param key The key of this value.
 * @param key_len The length of key.
 * @param value The value to save.
 *
 * @return  The result of pushing.
 */
int lpush_uint64_list(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, uint64_t value);

/**
 * @brief Pop a uint64 value from a list's left side.
 *
 * @param key_slot The slot of this key.
 * @param table_id The table id which user select.
 * @param key The key of this value.
 * @param key_len The length of key.
 * @param value The value will be saved to.
 *
 * @return The result of popping.
 */
int lpop_uint64_list(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, uint64_t *value);

/**
 * @brief Save a uint64 value.
 *
 * @param key_slot The slot of this key.
 * @param table_id The table id which user select.
 * @param key The key of this value.
 * @param key_len The length of key.
 * @param value The value to save.
 *
 * @return The result of saving.
 */
int save_uint64_value(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, uint64_t value);

/**
 * @brief Add a value to a uint64 value.
 *
 * @param key_slot The slot of this key.
 * @param table_id The table id which user select.
 * @param key The key of this value.
 * @param key_len The length of key.
 * @param value The value to save.
 *
 * @return The result of saving.
 */
int add_uint64_value(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, uint64_t value);

/**
 * @brief Save cache value of a uint64 value.
 *
 * @param key_slot The slot of this key.
 * @param table_id The table id which user select.
 * @param key The key of this value.
 * @param key_len The length of key.
 * @param value The value to save.
 *
 * @return The result of saving.
 */
int save_uint64_value_cache(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, uint64_t value);


/**
 * @brief Load a uint64 value.
 *
 * @param key_slot The slot of this key.
 * @param table_id The table id which user select.
 * @param key The key of this value.
 * @param key_len The length of key.
 * @param value The value will be saved to.
 *
 * @return The result of loading.
 */
int load_uint64_value(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, uint64_t *value);

/**
 * @brief Load cache value of uint64 value.
 *
 * @param key_slot The slot of this key.
 * @param table_id The table id which user select.
 * @param key The key of this value.
 * @param key_len The length of key.
 * @param value The value will be saved to.
 *
 * @return The result of loading.
 */
int load_uint64_value_cache(key_slot *key_slot, uint16_t table_id, void *key, size_t key_len, uint64_t *value);

#endif //RDARM_INCLUDE_RDARM_INTERNAL_RDARM_STORE_H_
