/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#ifndef RDARM_INCLUDE_RDARM_INTERNAL_RDARM_NODE_H_
#define RDARM_INCLUDE_RDARM_INTERNAL_RDARM_NODE_H_

#include <rdma/rdma_cma.h>
#include <uthash.h>
#include <semaphore.h>
#include <stdbool.h>

#include "rdarm_internal/net/rdarm_request.h"

enum rdarm_node_state {
  RDARM_NODE_STATE_IDLE = 0,
  RDARM_NODE_STATE_LISTENING, /**< Server side connection is established. */
  RDARM_NODE_STATE_MIGRATING,
  RDARM_NODE_STATE_CONNECTED,
  RDARM_NODE_STATE_WORKING,
  RDARM_NODE_STATE_EXIT,
  RDARM_NODE_STATE_ERROR,
};

enum rdarm_connection_state {
  RDARM_CONNECTION_STATE_ERROR,
  RDARM_CONNECTION_STATE_DISCONNECTED,
  RDARM_CONNECTION_STATE_IDLE = 0,
  RDARM_CONNECTION_STATE_SERVER_CONNECT_HANDLE,
  RDARM_CONNECTION_STATE_CLIENT_ADDRESS_RESOLVED,
  RDARM_CONNECTION_STATE_CONNECTED,
  RDARM_CONNECTION_STATE_CONNECTED_AND_READY, /**< Ready means the server send command buffer address to client */
};

enum rdarm_connection_type {
  RDARM_CONNECTION_TYPE_MAIN = 0,
  RDARM_CONNECTION_TYPE_MIGRATION,
};

/**
 * The basic struct of a RDMA connection.
 */
typedef struct rdarm_connection {
  enum rdarm_connection_type type;
  bool is_active; /**< If this node is active side. */

  struct ibv_comp_channel *comp_channel;
  struct ibv_cq *cq;
  struct ibv_qp *qp;

  /* The memory region to save READ or WRITE data. */
  struct ibv_mr *communicate_mr;
  /* The real memory used to save data which will be read or write. The active side will use the first half of the buffer. */
  rdarm_complex_communicate_data *communicate_buf_array;
  struct ibv_send_wr *send_wr_array;
  uint32_t communicate_next_request_id;
  pthread_mutex_t communicate_buf_mutex;

  uint64_t
      remote_address; /**< Save the address which will write self commands to. */
  uint32_t
      remote_key; /**< Save the key which will write self commands to. */

  enum rdarm_connection_state connection_state; /**< The state of the connection.If this node is active side
                                                   * it will be R_C_S_CLIENT_ADDRESS_RESOLVED, otherwise R_C_S_SERVER_CONNECT_HANDLE.
                                                   * Finally it will be R_C_S_CONNECTED_AND_READY. */
  struct rdma_cm_id *cm_id; /**< The cm_id of this connection. */
  struct rdma_event_channel *cm_channel; /**< The cm channel of this connection. NULL if the node is passive side. */
  pthread_t cm_thread; /**< The thread to handle the cm events. NULL if the node is passive side. */
  sem_t sem; /**< The sem used to sync between the cm thread, cq thread and the caller thread. */

  pthread_t worker_thread; /**< The thread to handle message. */
} rdarm_connection;

/**
 * @brief Node of rdarm cluster.
 */
typedef struct rdarm_node {
  char address_str[INET_ADDRSTRLEN]; /**< The key of this node in hash map. */
  struct ibv_pd *pd; /**< The Protection Region of this RDARM. */
  struct sockaddr_in address;
  enum rdarm_node_state state; /**< The state of this node. */

  rdarm_connection connection;
  rdarm_connection *migrate_connection;

  uint16_t slot_begin; /**< The begin slot of this node. */
  uint16_t slot_amount; /**< The amount of slots of this node. */
  uint64_t remote_key_slots_address; /**< Save the address of remote key slots */
  uint32_t remote_key_slots_key; /**< Save the key of remote key slots */

  pthread_rwlock_t state_lock; /**< The lock used to protect the node state. */
  UT_hash_handle hh; /**< Hash handle for the hash table. */
} rdarm_node;

#endif //RDARM_INCLUDE_RDARM_INTERNAL_RDARM_NODE_H_
