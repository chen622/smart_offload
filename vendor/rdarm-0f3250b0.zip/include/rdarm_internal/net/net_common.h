/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#ifndef RDARM_SRC_NET_NET_COMMON_H_
#define RDARM_SRC_NET_NET_COMMON_H_

#include <rdma/rdma_verbs.h>

#include "rdarm.h"
#include "rdarm_internal/net/server_worker.h"

enum rdarm_connection_request_type {
  RDARM_CONNECTION_REQUEST_TYPE_NORMAL,
  RDARM_CONNECTION_REQUEST_TYPE_NORMAL_MIGRATION,
  RDARM_CONNECTION_REQUEST_TYPE_MIGRATION,
};

struct rdarm_connect_param {
  char ip[INET_ADDRSTRLEN];
  uint64_t address;
  uint32_t rkey;
  enum rdarm_connection_request_type type;
};

char *rdarm_connection_type_to_string(enum rdarm_connection_type type);

/**
 * @brief Initialize Queue Pair for a new RDMA connection.
 *
 * @param rdarm_cb The main structure of RDARM.
 * @param connection The basic structure of new connection.
 *
 * @return The result of setup. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int setup_qp(rdarm *rdarm_cb, rdarm_connection *connection);

/**
 * @brief Destroy the Queue Pair of a connection.
 *
 * @param connection The basic structure of connection.
 */
void destroy_qp(rdarm_connection *connection);

/**
 * @brief Allocate memory and register Memory Region.
 *
 * @param rdarm_cb The main structure of RDARM.
 * @param connection The basic structure of new connection.
 *
 * @return The result of setup. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int setup_memory(rdarm *rdarm_cb, rdarm_connection *connection);

/**
 * @brief Deregister the Memory Region of a connection.
 *
 * @param connection The basic structure of connection.
 */
void destroy_memory(rdarm_connection *connection);

/**
 * @brief Send the address and key of pre-allocated memory region for receiving message.
 *
 * @param rdarm_cb The main structure of rdarm.
 * @param node The node to send.
 * @return
 */
int send_pre_allocate_memory_info(rdarm *rdarm_cb, rdarm_node *node);

/**
 * @brief Make a cm connection with a remote node.
 *
 * @param args Include rdarm, node, connection.
 *
 * @return The result of making. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int make_cm_connection(struct general_args *args);

/**
 * @brief Destroy a cm connection
 *
 * @param connection
 */
void destroy_cm_connection(rdarm_connection *connection);

/**
 * @brief Make a connection request with creating a Queue Pair, registering Memory Region.
 *
 * @param args Include rdarm, node, connection.
 *
 * @return The result of making. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int make_client_side_connection(struct general_args *args, struct rdarm_connect_param *private_conn_param);

/**
 * @brief Post a receive WR to receive Write-IMM request.
 *
 * @param rdarm_cb The main structure of rdarm.
 * @param connection The connection to post receive WR.
 * @return
 */
int post_receive_work_request(rdarm *rdarm_cb, rdarm_connection *connection);
/**
 * @brief Get a free communicate buffer.
 *
 * @param connection The connection used to get a buffer.
 *
 * @return The index of free communicate buffer.
 * @retval -1     No free buffer.
 * @retval Other  Success.
 */
int get_free_communicate_buffer(rdarm_connection *connection);

/**
 * @brief Send a communicate buffer to remote.
 *
 * @param rdarm_cb The structure of rdarm.
 * @param connection The connection to send the buffer.
 * @param index The index of buffer.
 * @param is_replay Is replay or not.
 *
 * @return The result of posting WR. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int send_communicate_buffer(rdarm *rdarm_cb, rdarm_connection *connection, int index, bool is_replay);

/**
 * @brief Read remote key slots and copy to local.
 *
 * @param rdarm_cb The structure of rdarm.
 * @param local_node Used to get the slots to save in.
 * @param peer_node Used to read the slots from.
 *
 * @return The result of posting WR. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int read_remote_key_slots(rdarm *rdarm_cb, rdarm_node *local_node, rdarm_node *peer_node);

#endif //RDARM_SRC_NET_NET_COMMON_H_
