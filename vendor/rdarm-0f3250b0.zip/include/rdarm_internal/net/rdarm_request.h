/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#ifndef RDARM_SRC_NET_RDARM_REQUEST_H_
#define RDARM_SRC_NET_RDARM_REQUEST_H_

#include <stdint.h>
#include <linux/types.h>

#include "rdarm_common.h"
#include "rdarm_internal/rdarm_store.h"

#define rdarm_encode_request_id(id, index) (((id) << 12) | (index))
#define rdarm_decode_request_id_to_id(id) (id >> 12)
#define rdarm_decode_request_id_to_index(id) (id & 0x000FF)

#define RDARM_WR_ID_FLAG_MSG_SEND (((uint64_t) 1) << 63)
#define rdarm_send_wr_id(request_id) (RDARM_WR_ID_FLAG_MSG_SEND | (uint64_t)(request_id))
#define rdarm_is_send_wr(wr_id) (wr_id & RDARM_WR_ID_FLAG_MSG_SEND)


/**
 * @brief The size of meta data in each request buffer.
 */
#define RDARM_COMPLEX_COMMUNICATE_DATA_META_SIZE 12

/**
 * @brief The data structure used to save the data for sending simple request.
 */
#pragma pack(4)
union rdarm_simple_communicate_data {
  struct {
    /* Address of data to read */
    __be64 buf;
    /* Key used to read remote data */
    __be32 rkey;
    /* The size of data to read */
    __be32 size;
  } be_data;
  struct {
    uint64_t buf;
    uint32_t rkey;
    uint32_t size;
  } data;
};

enum rdarm_op_request_type {
  RDARM_OP_REQUEST_TYPE_UNKNOWN = 0,
  RDARM_OP_REQUEST_TYPE_SET_TUPLE_UINT64,
  RDARM_OP_REQUEST_TYPE_ADD_TUPLE_UINT64,
  RDARM_OP_REQUEST_TYPE_GET_TUPLE_UINT64
};

typedef struct rdarm_operation_request {
  enum rdarm_op_request_type type;
  uint16_t slot_index;
  uint16_t table_id;
  uint64_t value;
  char key[RDARM_KEY_LEN];
  pthread_spinlock_t lock;
} rdarm_operation_request;

typedef struct rdarm_operation_replay {
  enum rdarm_operation_result_type result;
  uint64_t value;
} rdarm_operation_replay;

typedef struct rdarm_batch_operation_request {
  uint16_t original_index;
  uint16_t table_id;
  uint64_t value;
  char key[RDARM_KEY_LEN];
} rdarm_batch_operation_request;

typedef struct rdarm_batch_operation_reply {
  enum rdarm_operation_result_type result;
  uint16_t original_index;
  uint64_t value;
} rdarm_batch_operation_reply;

typedef struct rdarm_async_operation_replay {
  enum rdarm_operation_result_type result;
  enum rdarm_op_request_type type;
  uint64_t value;
  uint16_t table_id;
  char key[RDARM_KEY_LEN];
} rdarm_async_operation_replay;

enum rdarm_request_type {
  RDARM_REQUEST_TYPE_UNREADY = 0,
  RDARM_REQUEST_TYPE_FREE,
  RDARM_REQUEST_TYPE_BUSY,

  RDARM_REQUEST_TYPE_ASYNC_OPERATE = 1 << 5,
  RDARM_REQUEST_TYPE_ASYNC_REPLAY,
  RDARM_REQUEST_TYPE_BLOCKING = 1 << 8, /**> Below requests will wait for the replay. */
  RDARM_REQUEST_TYPE_JOIN, /**> New node send request to join the cluster. */
  RDARM_REQUEST_TYPE_JOIN_REPLAY,
  RDARM_REQUEST_TYPE_OPERATE,
  RDARM_REQUEST_TYPE_OPERATE_REPLAY,
  RDARM_REQUEST_TYPE_BATCH_OPERATE,
  RDARM_REQUEST_TYPE_BATCH_OPERATE_REPLY,
  RDARM_REQUEST_TYPE_MIGRATE, /**> Node send request to other node in cluster after receive RDARM_REQUEST_TYPE_JOIN. */
};

/**
 * @brief The data structure used to save the data for sending complex request.
 */
typedef struct rdarm_complex_communicate_data {
  uint32_t request_id;
  uint32_t replay_to;
  int16_t request_type;
  uint16_t payload_size;
  union {
    struct {
      pthread_spinlock_t lock;
    } join_request;
    struct {
      uint64_t key_slots_addr;
      uint32_t key_slots_rkey;
      bool result;
    } join_replay;
    rdarm_operation_request operation_request;
    rdarm_operation_replay operation_replay;
    struct {
      enum rdarm_op_request_type type;
      uint16_t amount;
      struct rdarm_batch_operation_request operation_request[1];
      pthread_spinlock_t lock;
    } batch_operation_request;
    struct rdarm_batch_operation_reply batch_operation_reply[1];
    rdarm_async_operation_replay async_operation_replay;
    char payload[
        RDARM_COMPLEX_COMMUNICATE_DATA_SIZE - RDARM_COMPLEX_COMMUNICATE_DATA_META_SIZE];
  } payload;

} rdarm_complex_communicate_data;
#pragma pack()

#endif //RDARM_SRC_NET_RDARM_REQUEST_H_
