/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#include "rdarm_internal/net/net_common.h"

char *rdarm_connection_type_to_string(enum rdarm_connection_type type) {
  switch (type) {
    case RDARM_CONNECTION_TYPE_MAIN:return "RDARM_CONNECTION_TYPE_MAIN";
    case RDARM_CONNECTION_TYPE_MIGRATION:return "RDARM_CONNECTION_TYPE_MIGRATION";
    default:return "RDARM_CONNECTION_TYPE_UNKNOWN";
  }
}

/**
 * @brief Initialize Queue Pair for a new RDMA connection.
 *
 * @param rdarm_cb The main structure of RDARM.
 * @param connection The basic structure of new connection.
 *
 * @return The result of setup. Get the error msg by calling rdarm_error_string().
 * @retval 0     Success.
 * @retval Not 0 Failed.
 */
int setup_qp(rdarm *rdarm_cb, rdarm_connection *connection) {
  int ret = 0;

  connection->comp_channel = ibv_create_comp_channel(connection->cm_id->verbs);
  if (!connection->comp_channel) {
    zlog_error(rdarm_cb->logger, "failed to create completion channel: %s", strerror(errno));
    return RDARM_ERROR_COMPLETION_CHANNEL;
  }

  connection->cq =
      ibv_create_cq(connection->cm_id->verbs, RDARM_QP_DEPTH * 4, rdarm_cb, connection->comp_channel, 0);
  if (!connection->cq) {
    zlog_error(rdarm_cb->logger, "failed to create completion queue: %s", strerror(errno));
    ret = RDARM_ERROR_COMPLETION_QUEUE;
    goto err;
  }

  // Start to use comp_channel notification mechanism.
  ret = ibv_req_notify_cq(connection->cq, 0);
  if (ret) {
    zlog_error(rdarm_cb->logger, "failed to start comp_channel notify: %s", strerror(errno));
    ret = RDARM_ERROR_NOTIFY_CQ;
    goto err2;
  }

  struct ibv_qp_init_attr init_attr = {
      .cap = {
          .max_send_wr = RDARM_QP_DEPTH,
          .max_recv_wr = RDARM_QP_DEPTH,
          .max_recv_sge = 1,
          .max_send_sge = 1,
      },
      .qp_type = IBV_QPT_RC,
      .send_cq = connection->cq,
      .sq_sig_all = 1,
      .recv_cq = connection->cq,
  };

  ret = rdma_create_qp(connection->cm_id, rdarm_cb->self.pd, &init_attr);
  if (ret != 0) {
    zlog_error(rdarm_cb->logger, "failed to create queue pair: %s", strerror(errno));
    ret = RDARM_ERROR_QUEUE_PAIR;
    goto err2;
  }
  connection->qp = connection->cm_id->qp;
  return RDARM_SUCCESS;

  err2:
  ibv_destroy_cq(connection->cq);
  err:
  ibv_destroy_comp_channel(connection->comp_channel);
  return ret;
}

void destroy_qp(rdarm_connection *connection) {
  ibv_destroy_qp(connection->qp);

  ibv_destroy_cq(connection->cq);
  ibv_destroy_comp_channel(connection->comp_channel);
}

int setup_memory(rdarm *rdarm_cb, rdarm_connection *connection) {
  int ret = 0;

  connection->communicate_buf_array = calloc(RDARM_CONCURRENCY_WRITE, RDARM_COMPLEX_COMMUNICATE_DATA_SIZE);
  for (int i = 0; i < RDARM_CONCURRENCY_WRITE; ++i) {
    connection->communicate_buf_array[i].request_type = RDARM_REQUEST_TYPE_FREE;
  }
  if (!connection->communicate_buf_array) {
    zlog_error(rdarm_cb->logger, "failed to alloc memory for communicate buffer: %s", strerror(errno));
    ret = RDARM_ERROR_FAILED_TO_ALLOC_MEMORY;
    return ret;
  }

  connection->communicate_mr =
      ibv_reg_mr(rdarm_cb->self.pd,
                 connection->communicate_buf_array,
                 RDARM_CONCURRENCY_WRITE * RDARM_COMPLEX_COMMUNICATE_DATA_SIZE,
                 IBV_ACCESS_LOCAL_WRITE |
                     IBV_ACCESS_REMOTE_READ |
                     IBV_ACCESS_REMOTE_WRITE);
  if (!connection->communicate_mr) {
    zlog_error(rdarm_cb->logger, "failed to register MR for read_write buffer");
    ret = RDARM_ERROR_REGISTER_MR;
    goto err1;
  }

  connection->send_wr_array = calloc(RDARM_CONCURRENCY_WRITE, sizeof(struct ibv_send_wr));
  if (!connection->send_wr_array) {
    zlog_error(rdarm_cb->logger, "failed to alloc memory for work request: %s", strerror(errno));
    ret = RDARM_ERROR_FAILED_TO_ALLOC_MEMORY;
    goto err2;
  }

  return RDARM_SUCCESS;
  err2:
  ibv_dereg_mr(connection->communicate_mr);
  err1:
  free(connection->communicate_buf_array);
  return ret;
}

void destroy_memory(rdarm_connection *connection) {
  if (connection->communicate_mr) {
    ibv_dereg_mr(connection->communicate_mr);

    uint8_t padding = connection->is_active ? 0 : RDARM_CONCURRENCY_WRITE
        / 2; // The active side will use the first half of the buffer.

    for (uint8_t i = 0; i < RDARM_CONCURRENCY_WRITE / 2; ++i) {
      uint8_t index = i + padding;
      if (connection->communicate_buf_array[index].request_type == RDARM_REQUEST_TYPE_JOIN) {
        pthread_spin_unlock(&connection->communicate_buf_array[index].payload.join_request.lock);
        pthread_spin_destroy(&connection->communicate_buf_array[index].payload.join_request.lock);
      } else if (connection->communicate_buf_array[index].request_type == RDARM_REQUEST_TYPE_OPERATE) {
        pthread_spin_unlock(&connection->communicate_buf_array[index].payload.operation_request.lock);
        pthread_spin_destroy(&connection->communicate_buf_array[index].payload.operation_request.lock);
      }
    }
    free(connection->communicate_buf_array);
  }
}

int send_pre_allocate_memory_info(rdarm *rdarm_cb, rdarm_node *node) {
  int ret = 0;
  union rdarm_simple_communicate_data
      *data =
      (union rdarm_simple_communicate_data *) &node->connection.communicate_buf_array[RDARM_CONCURRENCY_WRITE / 2];
  data->be_data.buf = htobe64((long) node->connection.communicate_buf_array);
  data->be_data.rkey = htobe32(node->connection.communicate_mr->rkey);
  data->be_data.size = htobe32(RDARM_CONCURRENCY_WRITE);

  ret = rdma_post_write(node->connection.cm_id,
                        NULL,
                        data,
                        sizeof(union rdarm_simple_communicate_data),
                        node->connection.communicate_mr,
                        IBV_SEND_SIGNALED,
                        node->connection.remote_address,
                        node->connection.remote_key);
  if (ret) {
    zlog_error(rdarm_cb->logger, "failed to send pre allocate memory info: %s", strerror(ret));
    return RDARM_ERROR_POST_WR;
  }

  // Waiting for write completion.
  sem_wait(&node->connection.sem);
  zlog_debug(rdarm_cb->logger, "send address info: %ld %d",
             (long) node->connection.communicate_buf_array, node->connection.communicate_mr->rkey);

  memset(data, 0, sizeof(union rdarm_simple_communicate_data));
  ((rdarm_complex_communicate_data *)data)->request_type = RDARM_REQUEST_TYPE_FREE;
  return ret;
}

int make_cm_connection(struct general_args *args) {
  int ret = 0;
  struct rdarm_connection *connection = ((struct general_args *) args)->connection;
  struct rdarm_node *node = ((struct general_args *) args)->node;
  struct rdarm *rdarm_cb = ((struct general_args *) args)->rdarm_cb;

  connection->cm_channel = rdma_create_event_channel();
  if (!connection->cm_channel) {
    if (errno == ENODEV) {
      ret = RDARM_ERROR_NO_IB_DEVICE;
    } else {
      ret = RDARM_ERROR_CM_EVENT_CHANNEL;
    }
    return ret;
  }
//  zlog_debug(rdarm_cb->logger, "create RDMA_CM event channel (Client: %s) success", node->address_str);

  ret = rdma_create_id(connection->cm_channel, &connection->cm_id, args, RDMA_PS_TCP);
  if (ret) {
    zlog_error(rdarm_cb->logger, "rdma_create_id failed, ret(%d): %s", ret, strerror(errno));
    ret = RDARM_ERROR_CM_ID;
    goto err;
  }
//  zlog_debug(rdarm_cb->logger, "create RDMA_CM id (Client: %s) success", node->address_str);

  ret = sem_init(&connection->sem, 0, 0);
  if (ret) {
    zlog_error(rdarm_cb->logger, "failed to init client state sem: %s", strerror(errno));
    ret = RDARM_ERROR_FAILED_TO_CREATE_SEMAPHORE;
    goto err2;
  }
  pthread_mutex_init(&connection->communicate_buf_mutex, NULL);

  ret = pthread_create(&connection->cm_thread, NULL, cm_event_processor, args);
  if (ret) {
    zlog_error(rdarm_cb->logger, "failed to create CM processor thread: %s", strerror(errno));
    ret = RDARM_ERROR_CM_THREAD;
    goto err3;
  }

  ret = rdma_resolve_addr(connection->cm_id,
                          NULL,
                          (struct sockaddr *) &node->address,
                          RDARM_RESOLVED_ADDRESS_TIMEOUT_MS);
  if (ret) {
    zlog_error(rdarm_cb->logger, "failed to request resolve address: %s", strerror(errno));
    ret = RDARM_ERROR_RESOLVE_ADDRESS;
    goto err4;
  }


  // Wait for the resolve to complete. See cm_event_handler - RDMA_CM_EVENT_ROUTE_RESOLVED.
  sem_wait(&connection->sem);
  if (connection->connection_state != RDARM_CONNECTION_STATE_CLIENT_ADDRESS_RESOLVED) {
    zlog_error(rdarm_cb->logger, "failed to resolve address");
    ret = RDARM_ERROR_RESOLVE_ADDRESS;
    goto err4;
  }

  return RDARM_SUCCESS;

  err4:
  pthread_cancel(connection->cm_thread);
  pthread_join(connection->cm_thread, NULL);
  err3:
  pthread_mutex_destroy(&connection->communicate_buf_mutex);
  sem_destroy(&connection->sem);
  err2:
  rdma_destroy_id(connection->cm_id);
  err:
  rdma_destroy_event_channel(connection->cm_channel);
  return ret;
}

void destroy_cm_connection(rdarm_connection *connection) {
  pthread_cancel(connection->cm_thread);
  pthread_join(connection->cm_thread, NULL);
  pthread_mutex_destroy(&connection->communicate_buf_mutex);
  sem_destroy(&connection->sem);
//  rdma_disconnect(connection->cm_id);
  rdma_destroy_id(connection->cm_id);
  rdma_destroy_event_channel(connection->cm_channel);
}

int make_client_side_connection(struct general_args *args, struct rdarm_connect_param *private_conn_param) {
  struct rdarm_connection *connection = ((struct general_args *) args)->connection;
  struct rdarm_node *node = ((struct general_args *) args)->node;
  struct rdarm *rdarm_cb = ((struct general_args *) args)->rdarm_cb;
//  node->pd = rdarm_cb->self.pd;
  int ret = 0;
  ret = setup_qp(rdarm_cb, connection);
  if (ret != RDARM_SUCCESS) {
    return ret;
  }
//  zlog_debug(rdarm_cb->logger, "create QP with %s success", node->address_str);

//  ret = setup_memory(rdarm_cb, connection);
//  if (ret != RDARM_SUCCESS) {
//    goto err;
//  }
//  zlog_debug(rdarm_cb->logger, "register MR for %s success", node->address_str);

  ret = pthread_create(&connection->worker_thread, NULL, message_worker_thread, args);
  if (ret) {
    zlog_error(rdarm_cb->logger, "failed to create server worker thread: %s", strerror(errno));
    ret = RDARM_ERROR_FAILED_TO_CREATE_THREAD;
    goto err;
  }

  for (uint8_t i = 0; i < RDARM_QP_DEPTH; ++i) {
    ret = post_receive_work_request(rdarm_cb, connection);
    if (ret != RDARM_SUCCESS) {
      goto err2;
    }
  }


  memcpy(private_conn_param->ip, rdarm_cb->self.address_str, INET_ADDRSTRLEN);
  zlog_debug(rdarm_cb->logger,
             "send conn parameter: %lu %u %ld",
             (uint64_t) &node->connection.communicate_buf_array,
             node->connection.communicate_mr->rkey,
             sizeof(struct rdarm_connect_param));
  struct rdma_conn_param conn_param = {
      .private_data = private_conn_param,
      .private_data_len = sizeof(struct rdarm_connect_param),
      .responder_resources = 1,
      .initiator_depth = 1,
      .retry_count = 7,
      .rnr_retry_count = 7,
  };
  ret = rdma_connect(connection->cm_id, &conn_param);
  if (ret) {
    zlog_error(rdarm_cb->logger, "failed to request connect with server: %s", strerror(errno));
    ret = RDARM_ERROR_CREATE_CONNECTION;
    goto err2;
  }

  // Waiting for connection established. See cm_event_handler - RDMA_CM_EVENT_ESTABLISHED .
  sem_wait(&connection->sem);
  if (connection->connection_state != RDARM_CONNECTION_STATE_CONNECTED) {
    zlog_error(rdarm_cb->logger, "failed to connect server: %s", node->address_str);
    ret = RDARM_ERROR_CONNECT;
    goto err2;
  }
  zlog_info(rdarm_cb->logger,
            "%s|Client|%s| RDARM_CONNECTION_STATE_SERVER_CONNECT_HANDLE>RDARM_CONNECTION_STATE_CONNECTED",
            node->address_str, rdarm_connection_type_to_string(connection->type));

  return RDARM_SUCCESS;
  err2:
  pthread_cancel(connection->worker_thread);
  pthread_join(connection->worker_thread, NULL);
  err:
  destroy_qp(&node->connection);
  return ret;
}

int post_receive_work_request(rdarm *rdarm_cb, rdarm_connection *connection) {
  struct ibv_recv_wr imm_recv_wc;
  imm_recv_wc.wr_id = 0;
  imm_recv_wc.sg_list = NULL;
  imm_recv_wc.num_sge = 0;
  imm_recv_wc.next = NULL;
  if (ibv_post_recv(connection->cm_id->qp, &imm_recv_wc, NULL)) {
    zlog_error(rdarm_cb->logger, "failed to post recv: %s", strerror(errno));
    return RDARM_ERROR_POST_WR;
  }
  return RDARM_SUCCESS;
}

int get_free_communicate_buffer(rdarm_connection *connection) {
  pthread_mutex_lock(&connection->communicate_buf_mutex);
  uint16_t padding =
      connection->is_active ? 0 : RDARM_CONCURRENCY_WRITE / 2; // The active side will use the first half of the buffer.
  for (uint16_t i = 0; i < RDARM_CONCURRENCY_WRITE / 2; ++i) {
    uint16_t index = ((connection->communicate_next_request_id + i) % (RDARM_CONCURRENCY_WRITE / 2)) + padding;
    if (connection->communicate_buf_array[index].request_type == RDARM_REQUEST_TYPE_FREE) {
      connection->communicate_buf_array[index].request_type = RDARM_REQUEST_TYPE_BUSY;
      connection->communicate_buf_array[index].request_id =
          rdarm_encode_request_id(connection->communicate_next_request_id++, index);
      pthread_mutex_unlock(&connection->communicate_buf_mutex);
      return index;
    }
  }
  pthread_mutex_unlock(&connection->communicate_buf_mutex);
  return -1;
}

int send_communicate_buffer(rdarm *rdarm_cb, rdarm_connection *connection, int index, bool is_replay) {
  struct ibv_send_wr send_wr = {0};
  struct ibv_send_wr *bad_wr;
  struct ibv_sge sge = {
      .addr =  (uint64_t) &connection->communicate_buf_array[index],
      .lkey = connection->communicate_mr->lkey,
      .length = RDARM_COMPLEX_COMMUNICATE_DATA_META_SIZE + connection->communicate_buf_array[index].payload_size,
  };
  send_wr.wr_id = is_replay ? connection->communicate_buf_array[index].request_id
                             : rdarm_send_wr_id(connection->communicate_buf_array[index].request_id);
  send_wr.sg_list = &sge;
  send_wr.num_sge = 1;
  send_wr.opcode = IBV_WR_RDMA_WRITE_WITH_IMM;
//  send_wr.send_flags = IBV_SEND_SIGNALED;
  send_wr.send_flags = sge.length <= 60 ? IBV_SEND_INLINE : IBV_SEND_SIGNALED;
  send_wr.imm_data = htobe32(index);
  send_wr.wr.rdma.rkey = connection->remote_key;
  send_wr.wr.rdma.remote_addr = connection->remote_address + RDARM_COMPLEX_COMMUNICATE_DATA_SIZE * index;
  if (connection->communicate_buf_array[index].request_id == 0) {
    zlog_error(rdarm_cb->logger, "empty request");
  }
  int ret = ibv_post_send(connection->cm_id->qp, &send_wr, &bad_wr);
  if (ret) {
    zlog_error(rdarm_cb->logger, "failed to post write WR(0x%lx): %s", send_wr.wr_id, strerror(ret));
    return RDARM_ERROR_POST_WR;
  } else {
    zlog_debug(rdarm_cb->logger, "success post write WR(0x%lx)", send_wr.wr_id);
  }
  return RDARM_SUCCESS;
}



int read_remote_key_slots(rdarm *rdarm_cb, rdarm_node *local_node, rdarm_node *peer_node) {
  struct ibv_sge sge = {
      .addr = (uint64_t) (rdarm_cb->key_slots + local_node->slot_begin),
      .lkey = rdarm_cb->key_slots_mr->lkey,
      .length = local_node->slot_amount * sizeof(struct key_slot),
  };
  struct ibv_send_wr send_wr = {
      .wr_id = rdarm_send_wr_id(peer_node->migrate_connection->communicate_next_request_id++),
      .sg_list = &sge,
      .num_sge = 1,
      .opcode = IBV_WR_RDMA_READ,
      .send_flags = IBV_SEND_SIGNALED,
      .wr.rdma.remote_addr = peer_node->remote_key_slots_address + local_node->slot_begin * sizeof(struct key_slot),
      .wr.rdma.rkey = peer_node->remote_key_slots_key,
  };
  struct ibv_send_wr *bad_wr;
  int ret = ibv_post_send(peer_node->migrate_connection->cm_id->qp, &send_wr, &bad_wr);
  if (ret) {
    zlog_error(rdarm_cb->logger, "failed to post read WR(0x%lx): %s", send_wr.wr_id, strerror(ret));
    return RDARM_ERROR_POST_WR;
  } else {
    zlog_debug(rdarm_cb->logger, "success post read WR(0x%lx)", send_wr.wr_id);
  }
  return RDARM_SUCCESS;
}

//int read_remote_key_slots(rdarm *rdarm_cb, rdarm_node *local_node, rdarm_node *peer_node) {
//  int batch_size = 100;
//
//  struct ibv_sge *sges = calloc(local_node->slot_amount / batch_size + 1, sizeof(struct ibv_sge));
//  struct ibv_send_wr *send_wrs = calloc(local_node->slot_amount / batch_size + 1, sizeof(struct ibv_send_wr));
////  local_node->slot_amount = 10;
//  for (uint16_t i = 0; i < local_node->slot_amount; i += 100) {
//    uint16_t slot_index = (local_node->slot_begin + i) % RDARM_SLOT_NUM;
//    sges[i].lkey = rdarm_cb->key_slots_mr->lkey;
//    sges[i].addr = (uint64_t) (rdarm_cb->key_slots + slot_index);
//    sges[i].length = (local_node->slot_amount - i < 100 ? local_node->slot_amount - i : 100) * sizeof(struct key_slot);
//    send_wrs[i].wr_id =
//        rdarm_encode_read_request_id(peer_node->migrate_connection->communicate_next_request_id++, slot_index);
//    send_wrs[i].sg_list = &sges[i];
//    send_wrs[i].num_sge = 1;
//    send_wrs[i].opcode = IBV_WR_RDMA_READ;
//    send_wrs[i].send_flags = IBV_SEND_SIGNALED;
//    send_wrs[i].wr.rdma.remote_addr = peer_node->remote_key_slots_address + slot_index * sizeof(struct key_slot);
//    send_wrs[i].wr.rdma.rkey = peer_node->remote_key_slots_key;
//    if (i < local_node->slot_amount - 10) {
//      send_wrs[i].next = &send_wrs[i + 1];
//    }
//  }
//  struct ibv_send_wr *bad_wr;
//  int ret = ibv_post_send(peer_node->migrate_connection->cm_id->qp, send_wrs, &bad_wr);
//  if (ret) {
//    zlog_error(rdarm_cb->logger,
//               "failed to post %d read WRs, failed at 0x%lx: %s",
//               local_node->slot_amount,
//               bad_wr->wr_id,
//               strerror(errno));
//    free(sges);
//    free(send_wrs);
//    return RDARM_ERROR_POST_WR;
//  } else {
//    zlog_debug(rdarm_cb->logger, "success post %d read WRs", local_node->slot_amount);
//    free(sges);
//    free(send_wrs);
//    return RDARM_SUCCESS;
//  }
//}