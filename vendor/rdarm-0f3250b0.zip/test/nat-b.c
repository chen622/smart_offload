/*
 * MIT License
 * 
 * Copyright (c) 2022 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*/

#include <rte_malloc.h>
#include <sys/time.h>
#include <arpa/inet.h>

#include "flow_management.h"
#include "flow_meta.h"
#include "smart_offload.h"
#include "smart_load_balancer.h"


zlog_category_t *logger;

static void signal_handler(int signum) {
  if (signum == SIGINT || signum == SIGTERM) {
    zlog_info(logger, "Signal %d received, preparing to exit...",
              signum);
    force_quit = true;
  }
}

int main(int argc, char **argv) {
  zlog_category_t *worker_logger;

  /* General return value */
  int ret;
  char err_msg[MAX_ERROR_MESSAGE_LENGTH];
  /* Quantity of ports */
  uint16_t port_quantity;
  /* Quantity of slave works */
  uint16_t worker_quantity;
  uint16_t port_id = 0;

  /* Setup environment of DPDK */
  ret = rte_eal_init(argc, argv);
  if (ret < 0) {
    smto_exit(EXIT_FAILURE, "invalid EAL arguments");
  }

  /* Setup zlog */
  ret = zlog_init("conf/zlog.conf");
  if (ret) {
    smto_exit(EXIT_FAILURE, "zlog init failed");
  }

  logger = zlog_get_category("main");
  if (logger == NULL) {
    smto_exit(EXIT_FAILURE, "failed to initialize logger");
  }

  worker_logger = zlog_get_category("worker");
  if (logger == NULL) {
    smto_exit(EXIT_FAILURE, "failed to initialize worker logger");
  }

  /* Check the instruction */
#if defined(__SSE2__)
  zlog_debug(logger, "Find SSE2 support");
#else
#error No vector engine (SSE, NEON, ALTIVEC) available, check your toolchain
#endif

  /* Listen to the shutdown event */
  force_quit = false;
  signal(SIGINT, signal_handler);
  signal(SIGTERM, signal_handler);

  zlog_debug(logger, "Running on socket #%d", rte_socket_id());

  /* Check the quantity of network ports */
  port_quantity = rte_eth_dev_count_avail();
  if (port_quantity < 1) {
    smto_exit(EXIT_FAILURE, "no enough Ethernet ports found");
  } else if (port_quantity > 2) {
    zlog_info(logger, "%d ports detected, but we only use two", port_quantity);
  }

  /* Check the quantity of workers */
  worker_quantity = rte_lcore_count();
  if (worker_quantity != GENERAL_QUEUES_QUANTITY + 1) {
    snprintf(err_msg, MAX_ERROR_MESSAGE_LENGTH,
             "worker quantity does not match the queue quantity, it should be %u rather than %u",
             GENERAL_QUEUES_QUANTITY + 1, worker_quantity);
    smto_exit(EXIT_FAILURE, err_msg);
  }

  /* Initialize the memory pool of dpdk */
  struct rte_mempool *mbuf_pool = rte_pktmbuf_pool_create("mbuf_pool", NUM_MBUFS, CACHE_SIZE, 0,
                                                          RTE_MBUF_DEFAULT_BUF_SIZE,
                                                          rte_socket_id());
  if (mbuf_pool == NULL) {
    smto_exit(EXIT_FAILURE, "cannot init mbuf pool");
  }

  /* Config port and setup hairpin mode */
  if (port_quantity == 1) {
    zlog_debug(logger, "ONE port hairpin mode");
    port_id = rte_eth_find_next_owned_by(0, RTE_ETH_DEV_NO_OWNER);
    init_port(port_id, mbuf_pool);
    setup_one_port_hairpin(port_id);
  } else {
    zlog_debug(logger, "TWO port hairpin mode");
    /* Initialize the network port and do some configure */
    RTE_ETH_FOREACH_DEV(port_id) {
      init_port(port_id, mbuf_pool);
    }
    setup_two_port_hairpin();
  }

  struct rte_flow *flow = 0;
  struct rte_flow_error flow_error = {0};
  flow = create_default_rss_flow(1, GENERAL_QUEUES_QUANTITY, &flow_error);
  if (flow == NULL) {
    snprintf(err_msg, MAX_ERROR_MESSAGE_LENGTH,
             "the default rss flow create failed: %s", flow_error.message);
    smto_exit(EXIT_FAILURE, err_msg);
  }

  /* Initialize the rdarm */
  rdarm *rdarm_cb;
  ret = rdarm_init(&rdarm_cb, "10.1.1.2", "10.1.1.1");
  if (ret) {
    zlog_error(logger, "rdarm init failed: %s", rdarm_error_string(ret));
    smto_exit(EXIT_FAILURE, "rdarm init failed");
  }

//  init_port_stack(rdarm_cb, 20);

  uint16_t lcore_id = 0;
  uint16_t index = 0;
  const int operations_count = 500000;
  long **time_use = 0;
  time_use = calloc(GENERAL_QUEUES_QUANTITY, sizeof(long *));
  for (int i = 0; i < GENERAL_QUEUES_QUANTITY; ++i) {
    time_use[i] = calloc(operations_count, sizeof(long));
  }

  struct worker_parameter worker_params[GENERAL_QUEUES_QUANTITY];
  RTE_LCORE_FOREACH_WORKER(lcore_id) {
    worker_params[index].port_id = 1;
    worker_params[index].queue_id = index;
    worker_params[index].rdarm_cb = rdarm_cb;
    worker_params[index].logger = worker_logger;
    worker_params[index].time_uses = time_use[index];
    worker_params[index].operations_count = operations_count;
    worker_params[index].rip = rte_cpu_to_be_32(inet_addr(REAL_IP));
    if (ret < 0) {
      zlog_info(logger, "worker #%u does not running at the fixed frequency", lcore_id);
    }
    rte_eal_remote_launch(process_loop, &worker_params[index], lcore_id);
    index++;
  }

  rte_eal_mp_wait_lcore();

  rdarm_destroy(rdarm_cb);

  smto_exit(EXIT_SUCCESS, "SUCCESS! All core stop running!");
}