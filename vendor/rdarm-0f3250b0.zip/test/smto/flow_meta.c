/*
 * MIT License
 *
 * Copyright (c) 2021 Chenming C (ccm@ccm.ink)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include <arpa/inet.h>
#include "include/flow_meta.h"

/*
struct flow_meta *create_flow_meta(uint32_t pkt_len, union ipv4_5tuple_host *routed_flow_map_value)
{
    struct flow_meta *data = rte_zmalloc("flow_table_data", sizeof(struct flow_meta), 0);
    data->create_at = rte_rdtsc(); // The number of cycles of CPU. One cycle is 1/rte_get_tsc_hz() second.
    data->flow_size = pkt_len;
    data->packet_amount = 1;
    data->flow = NULL;
    data->is_offload = false;
    data->routed_flow_map_value = routed_flow_map_value;
    return data;
}
*/

void dump_pkt_info(struct rdarm_five_tuple *key, uint16_t queue_index, char *result, int result_length) {
  char src_ip[INET_ADDRSTRLEN] = {0};
  char dst_ip[INET_ADDRSTRLEN] = {0};
  inet_ntop(AF_INET, &key->ip1, src_ip, INET_ADDRSTRLEN);
  inet_ntop(AF_INET, &key->ip2, dst_ip, INET_ADDRSTRLEN);

  snprintf(result, result_length, "%s:%u->%u->%s:%u - queue=0x%x", src_ip, key->port1, key->proto, dst_ip, key->port2,
           (unsigned int) queue_index);
}
