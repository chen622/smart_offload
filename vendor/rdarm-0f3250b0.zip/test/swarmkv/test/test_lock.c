#include<stdio.h>
#include <stdint.h>
#include <pthread.h>

struct inc_loc
{
    int b;
    pthread_rwlock_t rwlock_in;
};

struct test_lock
{
    int a;
    struct inc_lock *in_s;
    pthread_rwlock_t rwlock;
};

void main()
{
    struct inc_loc *s2 = (struct inc_loc*)malloc(sizeof(struct inc_loc)*1);
    pthread_rwlock_init(&s2->rwlock_in, NULL);
    struct test_lock *s1 = (struct test_lock*)malloc(sizeof(struct test_lock)*1);
    pthread_rwlock_init(&s1->rwlock, NULL);
    s1->in_s = s2;
    pthread_rwlock_wrlock(&s1->rwlock);
    printf("out lock\n");
    pthread_rwlock_wrlock(&s2->rwlock_in);
    printf("in lock\n");
}
